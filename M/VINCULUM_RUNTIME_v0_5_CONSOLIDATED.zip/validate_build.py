from __future__ import annotations
import compileall, json, subprocess, sys
ok=compileall.compile_dir("vinculum",quiet=1)
print("SYNTAX", "PASS" if ok else "FAIL")
r=subprocess.run([sys.executable,"-m","pytest","-q","tests"],text=True,capture_output=True)
print(r.stdout); print(r.stderr,file=sys.stderr)
raise SystemExit(r.returncode if ok else 1)
