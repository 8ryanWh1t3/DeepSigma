# Migration from v0.4

| v0.4 file | v0.5 destination |
|---|---|
| `models.py` | `vinculum/core/models.py` |
| `ledger.py` | `vinculum/core/ledger.py` |
| `deep_sigma_runtime.py` | `vinculum/runtime.py` + `vinculum/deep_sigma/coherence.py` |
| `manual_cerpa.py` | `vinculum/deep_sigma/manual_cerpa.py` |
| `escalation_policy.py` | `vinculum/deep_sigma/escalation.py` |
| `meridian_coordinates.py` | `vinculum/meridian/coordinates.py` |
| `meridian_runtime.py` | decomposed into coherence/mission/degraded/multi-agent modules |
| `lmstudio_adapter.py` | `vinculum/adapters/lmstudio.py` + common adapter contract |
| `vinculum_runtime.py` | `vinculum/runtime.py` + `vinculum/cli.py` |

The old standalone modules are intentionally not retained as duplicates.
