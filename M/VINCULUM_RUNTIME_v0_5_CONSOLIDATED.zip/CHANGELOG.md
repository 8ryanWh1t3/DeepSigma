# Changelog

## 0.5.0 — Consolidated Baseline

### Consolidated
- v0.1 LM Studio harness
- v0.2 VINCULUM identity / model-adjacent boundary
- v0.3 dual-tempo supervisory flow
- v0.4 MERIDIAN coordinate model

### Corrected
- Removed the architectural implication that VINCULUM owns a second canonical CERPA implementation.
- Preserved historical lineage: JIT (2016) and ONG (2020) predate the correction-loop phase.
- Separated internal Autonomy Coherence/MERIDIAN architecture from the public DoW Project Meridian study.

### Added
- mission testing
- degraded/disconnected reconciliation
- multi-agent coherence
- DoD-oriented evidence profile
- transition-evidence run
- adapter standard
- Deep Sigma Core capability bridge/probe
- recovered Folding/Origami, Cartography, envHarness, Zipf Compensator, Liddell Lens, Trinity/Nano Sigma integration ports
