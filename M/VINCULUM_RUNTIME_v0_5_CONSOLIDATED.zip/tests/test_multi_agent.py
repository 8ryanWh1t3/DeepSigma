from vinculum.meridian.multi_agent import AgentState, rollup

def test_team_rollup():
    intent="mission"
    agents=[AgentState("a","sensor",intent,["observe"],coherence_score=.9),AgentState("b","planner",intent,["recommend"],coherence_score=.8)]
    r=rollup(agents,intent); assert r.mission_coherent and r.agent_count==2
