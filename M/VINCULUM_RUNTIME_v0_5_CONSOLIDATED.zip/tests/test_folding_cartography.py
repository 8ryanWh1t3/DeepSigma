from vinculum.folding.model import Fold, FoldingEpisode, FOLDING_ANALOGY
from vinculum.folding.journal import FoldingJournal
from vinculum.cartography.map import SemanticMap,MapNode,MapEdge

def test_folding_unfold_and_journal(tmp_path):
    e=FoldingEpisode("e",{"t":1},{"words":["x"]},{"n":1},[Fold("f","interpretation","c",["ev"])])
    assert e.traceable() and e.unfold()[0]["fold_id"]=="f" and FOLDING_ANALOGY["unfolding"]=="explanation / audit"
    j=FoldingJournal(tmp_path/"j.db"); h=j.commit("v1",{"x":1},None); assert j.head()["payload_hash"]==h
    try: j.commit("v2",{"x":2},None); assert False
    except ValueError as ex: assert str(ex)=="STALE_WRITE"

def test_cartography_trace_impact():
    m=SemanticMap(); [m.add_node(MapNode(x,"x",x,["e"])) for x in ["a","b","c"]]
    m.add_edge(MapEdge("a","rel","b",["e"])); m.add_edge(MapEdge("b","rel","c",["e"]))
    assert m.trace("a","c")==["a","b","c"] and m.impact("a")=={"b","c"}
