from vinculum.meridian.mission_testing import MissionMetrics, compare

def test_comparative_advantage():
    b=MissionMetrics(mission_effectiveness=.7,time_to_effect=10,error_rate=.1)
    e=MissionMetrics(mission_effectiveness=.8,time_to_effect=8,error_rate=.05)
    r=compare(b,e); assert r.improved==3 and r.regressed==0
