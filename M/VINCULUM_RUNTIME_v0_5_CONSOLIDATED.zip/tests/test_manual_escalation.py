from pathlib import Path
from vinculum.deep_sigma.manual_cerpa import ManualCerpaQueue
from vinculum.deep_sigma.escalation import EscalationPolicy
from vinculum.core.models import ReviewResult, CoherenceContext, ReasoningFrame

def test_manual_queue(tmp_path):
    q=ManualCerpaQueue(tmp_path/"q.jsonl"); r=ReviewResult("PASS",.95)
    c=q.open("test","p","candidate",r); assert c.state=="OPEN"
    assert q.decide(c.case_id,"approve").state=="APPROVED"

def test_consequential_escalates():
    c=CoherenceContext([],ReasoningFrame("x"),world_state={"consequential_action":True})
    d=EscalationPolicy().evaluate(ReviewResult("PASS",.99),c); assert d.required
