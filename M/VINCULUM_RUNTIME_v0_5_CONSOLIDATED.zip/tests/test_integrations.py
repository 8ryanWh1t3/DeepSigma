from vinculum.integrations.trinity import TRINITY_RULE
from vinculum.integrations.nano_sigma import NANO_SIGMA_FORMULA
from vinculum.lineage.jit import JITDimensions

def test_integration_contracts_and_jit_four_lenses():
    assert "PATHFINDER" in TRINITY_RULE and NANO_SIGMA_FORMULA=="Trinity + LatticeDB + SQLite"
    d=JITDimensions(1,1,1,1); assert d.readiness()==1
