from vinculum.experimental.envharness import *
from vinculum.experimental.zipf import EvidenceItem, prioritize
from vinculum.experimental.liddell import CaseMetrics, compare

def test_envharness_gates_and_ranking():
    r=SemanticResidual("r","x","y",[Hypothesis("h","alt",.5)])
    tests=[CandidateTest("a","safe",.9,.8,cost=1,risk=.1,time=1),CandidateTest("b","risky",1,1,cost=1,risk=9,time=1)]
    ranked=rank_tests(r,tests,max_cost=2,max_risk=1,max_time=2); assert ranked[0].test.test_id=="a" and ranked[-1].eligible is False

def test_zipf_dedup_and_mandatory():
    items=[EvidenceItem("i1","o1","x",.5,.5,.5,.5),EvidenceItem("i2","o1","x",.6,.6,.5,.5),EvidenceItem("m","o2","alert",1,1,0,1,mandatory=True)]
    r=prioritize(items); assert r[0].item_id=="m" and len(r)==2

def test_liddell_reduction_positive():
    b=CaseMetrics(10,4,3,2,20,2,1); p=CaseMetrics(8,2,2,1,15,3,1)
    r=compare(b,p); assert r["staff_effort"]==2 and r["elapsed_decision_time"]==5 and r["preparation_cost"]==-1
