from vinculum.profiles.dod_autonomy import ProfileEvidence, evaluate

def test_profile_semantics():
    r=evaluate(ProfileEvidence(True,True,True,True,True,False,None))
    assert r["TRACEABLE"]=="PASS" and r["EQUITABLE"]=="N/A"
