from vinculum.adapters.mock import MockAdapter

def test_adapter_contract():
    a=MockAdapter(["hello"]); r=a.complete("s","u"); assert r.content=="hello" and a.list_models()==["mock"]
