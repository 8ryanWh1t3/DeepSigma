import inspect
from vinculum.lineage import jit, ong, timeline

def test_lineage_dates():
    assert [x.period for x in timeline.LINEAGE]==["2016","2020","2024-2025","2026"]

def test_jit_historical_invariant():
    src=inspect.getsource(jit).lower()
    assert "claim -> event" not in src
    assert "cerpa" not in src

def test_ong_historical_invariant():
    src=inspect.getsource(ong).lower()
    assert "claim -> event" not in src
    assert "cerpa" not in src

def test_jit_correspondence():
    r=jit.verify_correspondence({"a":1,"b":2},{"a":1,"b":3})
    assert r.correspondence_score==0.5 and r.mismatches==["b"]
