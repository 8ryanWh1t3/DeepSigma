import json
from vinculum.adapters.mock import MockAdapter
from vinculum.runtime import VinculumRuntime
from vinculum.core.models import TruthRecord,ReasoningFrame,MemoryRecord,CoherenceContext

def good_ctx(**world):
    return CoherenceContext([TruthRecord("t","truth","evidence","source")],ReasoningFrame("intent",["constraint"],["human"]),[MemoryRecord("m","memory")],world)

def review(status="PASS",confidence=.95):
    return json.dumps({"status":status,"confidence":confidence,"unsupported_claims":[],"contradictions":[],"authority_issues":[],"drift_signals":[],"patch_instructions":[],"rationale":"ok"})

def test_runtime_pass(tmp_path):
    a=MockAdapter(["candidate",review()]); rt=VinculumRuntime(a,tmp_path/"l.jsonl",tmp_path/"q.jsonl")
    r=rt.execute("prompt",good_ctx()); assert r.applied and r.status=="PASS"

def test_runtime_manual_for_consequence(tmp_path):
    a=MockAdapter(["candidate",review()]); rt=VinculumRuntime(a,tmp_path/"l.jsonl",tmp_path/"q.jsonl")
    r=rt.execute("prompt",good_ctx(consequential_action=True)); assert not r.applied and r.manual_case_id
