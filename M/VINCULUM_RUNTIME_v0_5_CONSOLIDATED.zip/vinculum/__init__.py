"""VINCULUM Runtime — Deep Sigma model-adjacent coherence harness."""
from .version import PRODUCT, SUBTITLE, VERSION
__all__ = ["PRODUCT", "SUBTITLE", "VERSION"]
