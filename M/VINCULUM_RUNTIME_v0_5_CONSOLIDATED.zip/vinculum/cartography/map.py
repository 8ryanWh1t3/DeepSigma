"""Governed semantic cartography.

Maps/traces/assesses/proposes. It does not approve or APPLY changes.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from collections import defaultdict, deque
from typing import Any, Dict, List, Optional, Set, Tuple

@dataclass
class MapNode:
    node_id: str
    kind: str
    label: str
    evidence_refs: List[str]=field(default_factory=list)
    authority: Optional[str]=None
    metadata: Dict[str,Any]=field(default_factory=dict)

@dataclass
class MapEdge:
    source: str
    predicate: str
    target: str
    evidence_refs: List[str]=field(default_factory=list)
    metadata: Dict[str,Any]=field(default_factory=dict)

@dataclass
class GapRecord:
    kind: str
    subject_id: str
    detail: str
    severity: str="review"

class SemanticMap:
    def __init__(self):
        self.nodes: Dict[str,MapNode]={}; self.edges: List[MapEdge]=[]; self.gaps: List[GapRecord]=[]

    def add_node(self,node:MapNode): self.nodes[node.node_id]=node
    def add_edge(self,edge:MapEdge):
        if edge.source not in self.nodes or edge.target not in self.nodes: raise KeyError("edge endpoint missing")
        self.edges.append(edge)

    def trace(self,start:str,end:str)->List[str]:
        adj=defaultdict(list)
        for e in self.edges: adj[e.source].append(e.target)
        q=deque([(start,[start])]); seen={start}
        while q:
            n,path=q.popleft()
            if n==end: return path
            for nxt in adj[n]:
                if nxt not in seen: seen.add(nxt); q.append((nxt,path+[nxt]))
        return []

    def impact(self,node_id:str)->Set[str]:
        rev=defaultdict(list)
        for e in self.edges: rev[e.source].append(e.target)
        out=set(); q=deque([node_id])
        while q:
            n=q.popleft()
            for nxt in rev[n]:
                if nxt not in out: out.add(nxt); q.append(nxt)
        out.discard(node_id); return out

    def cycles(self)->List[List[str]]:
        adj=defaultdict(list)
        for e in self.edges: adj[e.source].append(e.target)
        cycles=[]; visiting=set(); stack=[]
        def dfs(n):
            visiting.add(n); stack.append(n)
            for nxt in adj[n]:
                if nxt in visiting:
                    i=stack.index(nxt); cycles.append(stack[i:]+[nxt])
                elif nxt not in stack: dfs(nxt)
            stack.pop(); visiting.discard(n)
        for n in self.nodes: dfs(n)
        # de-duplicate textually
        uniq=[]; seen=set()
        for c in cycles:
            k=tuple(c)
            if k not in seen: seen.add(k); uniq.append(c)
        return uniq
