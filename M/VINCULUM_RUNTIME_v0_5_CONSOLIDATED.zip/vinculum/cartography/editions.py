from __future__ import annotations
from dataclasses import asdict
from typing import Dict, Any
from ..folding.journal import FoldingJournal
from .map import SemanticMap

def serialize_map(m: SemanticMap) -> Dict[str,Any]:
    return {"nodes":[asdict(x) for x in m.nodes.values()],"edges":[asdict(x) for x in m.edges],"gaps":[asdict(x) for x in m.gaps]}

def commit_map(journal: FoldingJournal, edition: str, m: SemanticMap, expected_head_hash=None)->str:
    return journal.commit(edition,serialize_map(m),expected_head_hash)
