"""Orientation, Navigation, Guidance (2020) — movement through knowledge.

Historical invariant: this module predates the later correction-loop mechanism.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class MovementState:
    current_position: Dict[str, Any]
    candidate_paths: List[str] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    objective: str = ""


@dataclass
class ONGAssessment:
    orientation: bool
    navigation: bool
    guidance: bool
    issues: List[str] = field(default_factory=list)


def assess_movement(state: MovementState) -> ONGAssessment:
    issues = []
    orientation = bool(state.current_position)
    navigation = bool(state.candidate_paths) and bool(state.objective)
    guidance = bool(state.constraints) and bool(state.objective)
    if not orientation: issues.append("ORIENTATION_GAP")
    if not navigation: issues.append("NAVIGATION_GAP")
    if not guidance: issues.append("GUIDANCE_GAP")
    return ONGAssessment(orientation, navigation, guidance, issues)
