"""Journey Into Truth (2016) — verification / correspondence-to-reality lineage.

Historical invariant: this module predates and does not implement the later correction loop.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List


@dataclass(frozen=True)
class JITDimensions:
    legacy_of_precision: float
    density_of_exposure: float
    matrix_of_awareness: float
    ontological_grade: float

    def readiness(self) -> float:
        vals = [self.legacy_of_precision, self.density_of_exposure, self.matrix_of_awareness, self.ontological_grade]
        if any(v < 0 or v > 1 for v in vals):
            raise ValueError("JIT dimension scores must be 0..1")
        return sum(vals) / len(vals)


@dataclass
class VerificationResult:
    correspondence_score: float
    mismatches: List[str] = field(default_factory=list)
    evidence_gaps: List[str] = field(default_factory=list)


def verify_correspondence(map_state: Dict[str, object], reality_state: Dict[str, object]) -> VerificationResult:
    keys = sorted(set(map_state) | set(reality_state))
    mismatches, gaps, matched = [], [], 0
    for key in keys:
        if key not in map_state or key not in reality_state:
            gaps.append(key); continue
        if map_state[key] == reality_state[key]: matched += 1
        else: mismatches.append(key)
    denominator = max(1, len(keys))
    return VerificationResult(matched / denominator, mismatches, gaps)
