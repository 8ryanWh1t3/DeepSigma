from dataclasses import dataclass
from typing import List

@dataclass(frozen=True)
class LineageStage:
    period: str
    construct: str
    contribution: str
    systemization: str

LINEAGE: List[LineageStage] = [
    LineageStage("2016", "Journey Into Truth", "Verification / correspondence to reality", "Conceptual"),
    LineageStage("2020", "Orientation, Navigation, Guidance", "Movement through knowledge", "Conceptual / human-operational"),
    LineageStage("2024-2025", "Truth, Reasoning, Memory", "Coherence substrate; correction loop emerges", "Operational architecture"),
    LineageStage("2026", "Deep Sigma + VINCULUM + MERIDIAN", "Executable autonomy coherence", "Runtime"),
]
