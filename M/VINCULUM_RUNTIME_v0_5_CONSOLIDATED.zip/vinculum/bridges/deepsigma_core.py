from __future__ import annotations
from dataclasses import dataclass

@dataclass
class Capability:
    name: str
    available: bool
    detail: str

def probe() -> list[Capability]:
    caps=[]
    for name, module in [
        ("CERPA","core.cerpa"),
        ("CoherenceGate","core.coherence_gate"),
        ("MemoryGraph","core.memory_graph"),
        ("DriftSignal","core.drift_signal"),
    ]:
        try:
            __import__(module); caps.append(Capability(name,True,module))
        except Exception as exc:
            caps.append(Capability(name,False,type(exc).__name__))
    return caps
