from __future__ import annotations
from dataclasses import dataclass, field
from typing import List
from ..core.models import CoherenceContext, ReviewResult

@dataclass
class EscalationDecision:
    required: bool
    reasons: List[str] = field(default_factory=list)

class EscalationPolicy:
    def __init__(self, min_auto_apply_confidence: float = 0.80):
        self.min_auto_apply_confidence = min_auto_apply_confidence

    def evaluate(self, review: ReviewResult, ctx: CoherenceContext) -> EscalationDecision:
        reasons = []
        if review.status == "ESCALATE": reasons.append("reviewer_requested")
        if review.authority_issues: reasons.append("authority_issue")
        if review.confidence < self.min_auto_apply_confidence: reasons.append("low_review_confidence")
        for flag in ["manual_cerpa_required","consequential_action","authority_change","mission_intent_change","policy_change","risk_acceptance_change"]:
            if ctx.world_state.get(flag) is True: reasons.append(flag)
        return EscalationDecision(bool(reasons), reasons)
