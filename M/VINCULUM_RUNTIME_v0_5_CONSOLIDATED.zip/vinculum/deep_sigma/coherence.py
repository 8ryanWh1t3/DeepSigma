from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List
from ..core.models import CoherenceContext


@dataclass
class TRMAssessment:
    truth_ok: bool
    reasoning_ok: bool
    memory_ok: bool
    issues: List[str] = field(default_factory=list)

    @property
    def coherent(self) -> bool:
        return self.truth_ok and self.reasoning_ok and self.memory_ok


class TRMEvaluator:
    """Deterministic minimum checks for Truth + Reasoning + Memory."""
    def evaluate(self, ctx: CoherenceContext) -> TRMAssessment:
        issues = []
        truth_ok = False
        for t in ctx.truth:
            if not (t.claim.strip() and t.evidence.strip() and t.source.strip()):
                continue
            if not 0 <= t.confidence <= 1:
                issues.append(f"TRUTH_CONFIDENCE_RANGE:{t.id}")
                continue
            if t.valid_until:
                try:
                    exp = datetime.fromisoformat(t.valid_until.replace("Z", "+00:00"))
                    if exp.tzinfo is None: exp = exp.replace(tzinfo=timezone.utc)
                    if exp < datetime.now(timezone.utc):
                        issues.append(f"TRUTH_EXPIRED:{t.id}"); continue
                except ValueError:
                    issues.append(f"TRUTH_EXPIRY_INVALID:{t.id}"); continue
            truth_ok = True
        if not truth_ok: issues.append("TRUTH_GAP")
        reasoning_ok = bool(ctx.reasoning.intent.strip()) and bool(ctx.reasoning.constraints)
        if not ctx.reasoning.intent.strip(): issues.append("REASONING_INTENT_GAP")
        if not ctx.reasoning.constraints: issues.append("REASONING_CONSTRAINT_GAP")
        memory_ok = bool(ctx.memory) or bool(ctx.episode_id) or bool(ctx.world_state.get("current_state_id"))
        if not memory_ok: issues.append("MEMORY_ORIENTATION_GAP")
        return TRMAssessment(truth_ok, reasoning_ok, memory_ok, issues)
