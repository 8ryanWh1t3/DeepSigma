"""VINCULUM-to-Deep-Sigma CERPA bridge.

The canonical CERPA implementation lives in Deep Sigma Core (`core.cerpa`) when installed.
This module does not redefine the domain engine; it provides lifecycle naming and an optional bridge.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict

CERPA_PHASES = ("CLAIM", "EVENT", "REVIEW", "PATCH", "APPLY")

@dataclass
class CoreCerpaBridgeStatus:
    available: bool
    detail: str

class CoreCerpaBridge:
    def status(self) -> CoreCerpaBridgeStatus:
        try:
            import core.cerpa  # type: ignore
            return CoreCerpaBridgeStatus(True, "Deep Sigma Core CERPA available")
        except Exception as exc:
            return CoreCerpaBridgeStatus(False, f"Deep Sigma Core CERPA unavailable: {type(exc).__name__}")

    def run(self, claim: Dict[str, Any], event: Dict[str, Any]) -> Dict[str, Any]:
        from core.cerpa.engine import run_cerpa_cycle  # type: ignore
        from core.cerpa.models import Claim, Event  # type: ignore
        c = Claim(**claim); e = Event(**event)
        cycle = run_cerpa_cycle(c, e)
        return cycle.to_dict()
