from __future__ import annotations
import json, uuid
from dataclasses import asdict
from pathlib import Path
from typing import List, Literal, Optional
from ..core.models import ManualCerpaCase, ReviewResult, utc_now

class ManualCerpaQueue:
    """Human-speed authority queue. Open cases cannot be auto-applied."""
    def __init__(self, path: str | Path):
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)

    def _append(self, c: ManualCerpaCase):
        with self.path.open("a", encoding="utf-8") as f: f.write(json.dumps(asdict(c), ensure_ascii=False)+"\n")

    def current(self) -> List[ManualCerpaCase]:
        latest = {}
        if not self.path.exists(): return []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip(): continue
            raw=json.loads(line); raw["review"]=ReviewResult(**raw["review"])
            c=ManualCerpaCase(**raw); latest[c.case_id]=c
        return sorted(latest.values(), key=lambda c: c.created_at)

    def open(self, trigger: str, prompt: str, candidate: str, review: ReviewResult) -> ManualCerpaCase:
        c=ManualCerpaCase(f"MC-{uuid.uuid4().hex[:10].upper()}", utc_now(), "OPEN", trigger, prompt, candidate, review)
        self._append(c); return c

    def get(self, case_id: str) -> ManualCerpaCase:
        for c in self.current():
            if c.case_id == case_id: return c
        raise KeyError(case_id)

    def decide(self, case_id: str, decision: Literal["approve","reject","patch"], note: str="", final_response: Optional[str]=None) -> ManualCerpaCase:
        c=self.get(case_id)
        if c.state in ("APPROVED","REJECTED"): raise ValueError("case closed")
        c.state={"approve":"APPROVED","reject":"REJECTED","patch":"PATCH_REQUESTED"}[decision]
        c.operator_note=note; c.decided_at=utc_now()
        c.final_response=(final_response or c.candidate) if decision=="approve" else final_response if decision=="patch" else None
        self._append(c); return c
