"""Semantic / Origami Folding model.

Preserves the folding path, not only the finished shape.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List

FOLDING_ANALOGY = {
    "paper":"captured reality",
    "fibers":"original evidence",
    "coordinates":"metadata / provenance",
    "crease":"claim / relationship",
    "crease_pattern":"Reality Graph",
    "fold":"interpretation / design",
    "reverse_fold":"counterfold",
    "locked_fold":"authorized decision",
    "pressure":"action",
    "resistance":"unexpected outcome",
    "unfolding":"explanation / audit",
    "new_crease_memory":"learning",
    "torn_paper":"lost provenance / identity",
}

PRIMITIVE_ALIASES = {
    "TIME":"TIME",
    "WORDS":"LANGUAGE",
    "LANGUAGE":"LANGUAGE",
    "NUMBERS":"MATH",
    "MATH":"MATH",
}

@dataclass
class Fold:
    fold_id: str
    kind: str
    claim: str
    evidence_refs: List[str]=field(default_factory=list)
    relationships: List[str]=field(default_factory=list)
    authorized: bool=False
    metadata: Dict[str,Any]=field(default_factory=dict)

@dataclass
class FoldingEpisode:
    episode_id: str
    time_state: Dict[str,Any]
    language_state: Dict[str,Any]
    math_state: Dict[str,Any]
    folds: List[Fold]=field(default_factory=list)

    def unfold(self) -> List[Dict[str,Any]]:
        return [
            {"fold_id":f.fold_id,"claim":f.claim,"evidence_refs":list(f.evidence_refs),"authorized":f.authorized}
            for f in reversed(self.folds)
        ]

    def traceable(self) -> bool:
        return all(bool(f.evidence_refs) for f in self.folds)
