from __future__ import annotations
import hashlib, json, sqlite3
from pathlib import Path
from typing import Any, Dict, Optional

class FoldingJournal:
    """Small SQLite edition journal with hash-linked editions and stale-write rejection."""
    def __init__(self, path: str|Path):
        self.path=str(path)
        with sqlite3.connect(self.path) as c:
            c.execute("create table if not exists editions (id integer primary key autoincrement, edition text not null unique, predecessor_hash text, payload text not null, payload_hash text not null)")

    def head(self) -> Optional[Dict[str,Any]]:
        with sqlite3.connect(self.path) as c:
            r=c.execute("select edition, predecessor_hash, payload, payload_hash from editions order by id desc limit 1").fetchone()
        if not r: return None
        return {"edition":r[0],"predecessor_hash":r[1],"payload":json.loads(r[2]),"payload_hash":r[3]}

    def commit(self, edition: str, payload: Dict[str,Any], expected_head_hash: Optional[str]=None) -> str:
        head=self.head(); actual=head["payload_hash"] if head else None
        if expected_head_hash != actual:
            raise ValueError("STALE_WRITE")
        body=json.dumps(payload,sort_keys=True,separators=(",",":"),ensure_ascii=False)
        h=hashlib.sha256(body.encode()).hexdigest()
        with sqlite3.connect(self.path) as c:
            c.execute("insert into editions(edition,predecessor_hash,payload,payload_hash) values(?,?,?,?)",(edition,actual,body,h))
        return h
