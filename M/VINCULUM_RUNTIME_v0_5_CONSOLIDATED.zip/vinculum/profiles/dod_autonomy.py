"""DoD-oriented autonomy profile.

This is an engineering evidence profile, not a legal/compliance certification.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional

@dataclass
class ProfileEvidence:
    responsible_authority_defined: bool
    traceability_available: bool
    reliability_tested: bool
    governable_override_available: bool
    human_judgment_gate: bool
    equitable_assessment_applicable: bool=False
    equitable_assessment_completed: Optional[bool]=None


def evaluate(e: ProfileEvidence) -> Dict[str,str]:
    out={
        "RESPONSIBLE":"PASS" if e.responsible_authority_defined else "REVIEW",
        "TRACEABLE":"PASS" if e.traceability_available else "REVIEW",
        "RELIABLE":"PASS" if e.reliability_tested else "REVIEW",
        "GOVERNABLE":"PASS" if e.governable_override_available else "REVIEW",
        "HUMAN_JUDGMENT":"PASS" if e.human_judgment_gate else "REVIEW",
    }
    if not e.equitable_assessment_applicable: out["EQUITABLE"]="N/A"
    else: out["EQUITABLE"]="PASS" if e.equitable_assessment_completed else "REVIEW"
    return out
