"""envHarness — controlled test selector for semantic residuals.

Ranks staff-supplied discriminating tests; it does not authorize or apply model changes.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class Hypothesis:
    hypothesis_id: str
    description: str
    prior: float

@dataclass
class CandidateTest:
    test_id: str
    description: str
    expected_information_gain: float
    falsification_value: float
    cost: float=0.0
    risk: float=0.0
    time: float=0.0
    mode: str="analysis"
    authorized: bool=True

@dataclass
class SemanticResidual:
    residual_id: str
    expected: str
    observed: str
    hypotheses: List[Hypothesis]
    provenance: List[str]=field(default_factory=list)

@dataclass
class RankedTest:
    test: CandidateTest
    score: float
    eligible: bool
    reason: str

def rank_tests(residual: SemanticResidual, tests: List[CandidateTest], *, max_cost: float, max_risk: float, max_time: float, permitted_modes: Optional[List[str]]=None)->List[RankedTest]:
    permitted_modes=permitted_modes or ["analysis"]
    out=[]
    for t in tests:
        eligible=t.authorized and t.cost<=max_cost and t.risk<=max_risk and t.time<=max_time and t.mode in permitted_modes
        score=(t.expected_information_gain*.6+t.falsification_value*.4) if eligible else 0.0
        reason="eligible" if eligible else "authority/risk/cost/time/mode gate"
        out.append(RankedTest(t,score,eligible,reason))
    return sorted(out,key=lambda x:x.score,reverse=True)
