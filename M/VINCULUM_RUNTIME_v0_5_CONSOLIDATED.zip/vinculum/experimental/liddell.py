"""Liddell Lens — comparative measurement of preparation/CERPA effects; does not enforce."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict

@dataclass
class CaseMetrics:
    staff_effort: float
    rework: float
    clarification_cycles: float
    unresolved_contradictions: float
    elapsed_decision_time: float
    preparation_cost: float=0.0
    review_cost: float=0.0

def compare(baseline: CaseMetrics, prepared: CaseMetrics)->Dict[str,float]:
    b,p=asdict(baseline),asdict(prepared)
    # Positive means reduction/improvement because all measured quantities here are costs/frictions.
    return {k:b[k]-p[k] for k in b}
