"""Zipf Compensator — review prioritization, not a truth engine."""
from __future__ import annotations
from dataclasses import dataclass
from typing import List

@dataclass
class EvidenceItem:
    item_id: str
    origin_id: str
    concept: str
    relevance: float
    quality: float
    uncertainty: float
    consequence: float
    rarity: float=0.0
    mandatory: bool=False

@dataclass
class PriorityItem:
    item_id: str
    score: float
    mandatory: bool

def prioritize(items: List[EvidenceItem])->List[PriorityItem]:
    # Copies sharing origin_id do not multiply confidence or priority.
    by_origin={}
    for i in items:
        cur=by_origin.get(i.origin_id)
        if cur is None or (i.quality+i.relevance)>(cur.quality+cur.relevance): by_origin[i.origin_id]=i
    out=[]
    for i in by_origin.values():
        if i.mandatory: score=10_000.0
        else:
            bounded_rarity=max(0,min(1,i.rarity))*max(0,min(1,i.relevance))
            score=(i.relevance*.25+i.quality*.20+i.uncertainty*.20+i.consequence*.30+bounded_rarity*.05)
        out.append(PriorityItem(i.item_id,score,i.mandatory))
    return sorted(out,key=lambda x:(not x.mandatory,-x.score))
