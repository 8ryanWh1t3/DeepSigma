from __future__ import annotations
import argparse, json, os
from dataclasses import asdict
from .version import PRODUCT, SUBTITLE, VERSION, PRINCIPLE
from .core.context import load_context
from .adapters.lmstudio import LMStudioAdapter
from .runtime import VinculumRuntime
from .deep_sigma.manual_cerpa import ManualCerpaQueue
from .bridges.deepsigma_core import probe


def main():
    p=argparse.ArgumentParser(description=f"{PRODUCT} — {SUBTITLE}")
    p.add_argument("--model",default=os.getenv("LM_STUDIO_MODEL")); p.add_argument("--base-url",default=os.getenv("LM_STUDIO_URL","http://localhost:1234/v1"))
    p.add_argument("--prompt"); p.add_argument("--context"); p.add_argument("--list-models",action="store_true"); p.add_argument("--about",action="store_true"); p.add_argument("--probe-core",action="store_true")
    p.add_argument("--ledger",default="vinculum_runtime_ledger.jsonl"); p.add_argument("--manual-queue",default="vinculum_manual_cerpa.jsonl"); p.add_argument("--list-cases",action="store_true")
    p.add_argument("--case"); p.add_argument("--manual-decision",choices=["approve","reject","patch"]); p.add_argument("--note",default=""); p.add_argument("--final-response")
    a=p.parse_args()
    if a.about: print(f"{PRODUCT} v{VERSION}\n{SUBTITLE}\n{PRINCIPLE}"); return
    if a.probe_core: print(json.dumps([asdict(x) for x in probe()],indent=2)); return
    q=ManualCerpaQueue(a.manual_queue)
    if a.list_cases: print(json.dumps([asdict(x) for x in q.current()],indent=2)); return
    if a.case and a.manual_decision: print(json.dumps(asdict(q.decide(a.case,a.manual_decision,a.note,a.final_response)),indent=2)); return
    adapter=LMStudioAdapter(a.model or "__list__",a.base_url)
    if a.list_models: print("\n".join(adapter.list_models())); return
    if not a.model or not a.prompt or not a.context: raise SystemExit("--model, --prompt, and --context are required")
    result=VinculumRuntime(adapter,a.ledger,a.manual_queue).execute(a.prompt,load_context(a.context))
    print(json.dumps(asdict(result),indent=2,ensure_ascii=False))

if __name__=="__main__": main()
