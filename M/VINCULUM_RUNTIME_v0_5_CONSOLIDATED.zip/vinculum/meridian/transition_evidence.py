from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from .mission_testing import MissionMetrics, MissionTestResult, compare

@dataclass
class TransitionEvidenceRun:
    run_id: str
    mission_id: str
    baseline: MissionMetrics
    enabled: MissionMetrics
    injected_conditions: List[str]=field(default_factory=list)
    detected_signals: List[str]=field(default_factory=list)
    corrections: List[str]=field(default_factory=list)
    recovered: Optional[bool]=None

    def measure(self) -> MissionTestResult:
        return compare(self.baseline,self.enabled)
