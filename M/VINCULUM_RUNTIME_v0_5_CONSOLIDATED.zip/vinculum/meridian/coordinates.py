from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple

@dataclass(frozen=True)
class Axis:
    primitive: str
    pillar: str
    function: str
    question: str

AXES: Tuple[Axis, ...] = (
    Axis("TIME", "MEMORY", "ORIENTATION", "Where am I relative to what came before?"),
    Axis("LANGUAGE", "REASONING", "NAVIGATION", "What does this mean, and how should I move?"),
    Axis("MATH", "TRUTH", "GUIDANCE", "Am I still inside reality and bounded constraints?"),
)

def validate() -> List[str]:
    expected={"TIME":("MEMORY","ORIENTATION"),"LANGUAGE":("REASONING","NAVIGATION"),"MATH":("TRUTH","GUIDANCE")}
    issues=[]
    for a in AXES:
        if (a.pillar,a.function)!=expected[a.primitive]: issues.append(a.primitive)
    return issues

def as_dict() -> Dict[str, object]:
    return {"axes":[asdict(a) for a in AXES]}

EXECUTIVE_LINES = {
    "ORIENTATION":"Memory tells autonomy where it is.",
    "NAVIGATION":"Reasoning tells autonomy how to move.",
    "GUIDANCE":"Truth tells autonomy whether it should.",
    "PRIMITIVES":"Time gives position. Language gives meaning. Math gives constraint.",
}
