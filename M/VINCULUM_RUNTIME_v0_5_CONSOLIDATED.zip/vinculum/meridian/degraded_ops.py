from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Any

class ConnectivityState(str, Enum):
    CONNECTED="CONNECTED"; DEGRADED="DEGRADED"; DISCONNECTED="DISCONNECTED"; REJOINING="REJOINING"; RECONCILING="RECONCILING"

ALLOWED = {
    ConnectivityState.CONNECTED:{ConnectivityState.DEGRADED,ConnectivityState.DISCONNECTED},
    ConnectivityState.DEGRADED:{ConnectivityState.CONNECTED,ConnectivityState.DISCONNECTED,ConnectivityState.REJOINING},
    ConnectivityState.DISCONNECTED:{ConnectivityState.REJOINING},
    ConnectivityState.REJOINING:{ConnectivityState.RECONCILING,ConnectivityState.DISCONNECTED},
    ConnectivityState.RECONCILING:{ConnectivityState.CONNECTED,ConnectivityState.DISCONNECTED},
}

def can_transition(src: ConnectivityState, dst: ConnectivityState) -> bool:
    return dst in ALLOWED[src]

@dataclass
class ReconciliationReport:
    truth_conflicts: List[str]=field(default_factory=list)
    decision_conflicts: List[str]=field(default_factory=list)
    memory_conflicts: List[str]=field(default_factory=list)
    authority_conflicts: List[str]=field(default_factory=list)
    @property
    def clean(self)->bool: return not any([self.truth_conflicts,self.decision_conflicts,self.memory_conflicts,self.authority_conflicts])


def reconcile(local: Dict[str,Any], authoritative: Dict[str,Any]) -> ReconciliationReport:
    r=ReconciliationReport()
    for category, target in [("truth",r.truth_conflicts),("decisions",r.decision_conflicts),("memory",r.memory_conflicts),("authority",r.authority_conflicts)]:
        l=local.get(category,{}) or {}; a=authoritative.get(category,{}) or {}
        for k in sorted(set(l)|set(a)):
            if l.get(k)!=a.get(k): target.append(k)
    return r
