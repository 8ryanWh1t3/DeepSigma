from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, List

class AutonomyPhase(str, Enum):
    OBSERVE="OBSERVE"; MODEL="MODEL"; DECIDE="DECIDE"; ACT="ACT"; EFFECT="EFFECT"; LEARN="LEARN"; UPDATE="UPDATE"

@dataclass
class AutonomyState:
    phase: AutonomyPhase
    mission_id: str
    state: Dict[str, Any] = field(default_factory=dict)
    authority: List[str] = field(default_factory=list)
    intent: str = ""

AUTONOMY_LOOP = tuple(x.value for x in AutonomyPhase)
