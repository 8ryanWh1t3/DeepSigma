"""meridian package."""
