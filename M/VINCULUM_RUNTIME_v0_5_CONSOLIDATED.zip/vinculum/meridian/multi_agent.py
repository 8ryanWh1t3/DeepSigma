from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Any

@dataclass
class AgentState:
    agent_id: str
    role: str
    intent: str
    authority: List[str]
    truth_state: Dict[str,Any]=field(default_factory=dict)
    reasoning_state: Dict[str,Any]=field(default_factory=dict)
    memory_state: Dict[str,Any]=field(default_factory=dict)
    mission_state: Dict[str,Any]=field(default_factory=dict)
    coherence_score: float=1.0
    issues: List[str]=field(default_factory=list)

@dataclass
class TeamCoherence:
    agent_count: int
    average_coherence: float
    minimum_coherence: float
    intent_mismatches: List[str]
    authority_conflicts: List[str]
    mission_coherent: bool


def rollup(agents: List[AgentState], commander_intent: str) -> TeamCoherence:
    if not agents: return TeamCoherence(0,0.0,0.0,[],[],False)
    scores=[max(0,min(1,a.coherence_score)) for a in agents]
    mismatches=[a.agent_id for a in agents if a.intent and commander_intent and a.intent!=commander_intent]
    authority=[]
    for a in agents:
        if not a.authority: authority.append(a.agent_id)
    mission = min(scores)>=0.6 and not mismatches and not authority
    return TeamCoherence(len(agents),sum(scores)/len(scores),min(scores),mismatches,authority,mission)
