from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Optional

LOWER_IS_BETTER = {"time_to_effect","operator_workload","error_rate","adaptation_latency","recovery_time","confidence_calibration_error"}
HIGHER_IS_BETTER = {"mission_effectiveness","decision_quality"}

@dataclass
class MissionMetrics:
    mission_effectiveness: Optional[float]=None
    decision_quality: Optional[float]=None
    time_to_effect: Optional[float]=None
    operator_workload: Optional[float]=None
    error_rate: Optional[float]=None
    adaptation_latency: Optional[float]=None
    recovery_time: Optional[float]=None
    confidence_calibration_error: Optional[float]=None

@dataclass
class MissionTestResult:
    deltas: Dict[str, float]
    normalized_advantage: Dict[str, float]
    improved: int
    regressed: int
    unchanged: int


def compare(baseline: MissionMetrics, enabled: MissionMetrics) -> MissionTestResult:
    b,e=asdict(baseline),asdict(enabled); deltas={}; adv={}; improved=regressed=unchanged=0
    for k in b:
        if b[k] is None or e[k] is None: continue
        d=e[k]-b[k]; deltas[k]=d
        a=-d if k in LOWER_IS_BETTER else d
        adv[k]=a
        if a>0: improved+=1
        elif a<0: regressed+=1
        else: unchanged+=1
    return MissionTestResult(deltas,adv,improved,regressed,unchanged)
