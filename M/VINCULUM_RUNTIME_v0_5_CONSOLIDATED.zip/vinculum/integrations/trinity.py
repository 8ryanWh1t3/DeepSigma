"""Ports for Trinity integration. These interfaces do not reimplement the engines."""
from __future__ import annotations
from typing import Protocol, Any, Dict, List

class PathfinderPort(Protocol):
    def trace(self, start_id: str, end_id: str) -> List[str]: ...
    def impact(self, object_id: str) -> List[str]: ...

class ResonatorPort(Protocol):
    def compare(self, source: Any, target: Any) -> Dict[str,Any]: ...

class ComposerPort(Protocol):
    def propose(self, context: Dict[str,Any]) -> Dict[str,Any]: ...

TRINITY_RULE = "PATHFINDER navigates; RESONATOR evaluates; COMPOSER proposes governed change. Human authority/CERPA governs APPLY."
