from __future__ import annotations
import hashlib, json
from pathlib import Path
from typing import Any, Dict, List
from .models import utc_now


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


class HashLedger:
    """Hash-chained JSONL ledger. Tamper-evident, not immutable or a trust anchor."""
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _last_hash(self) -> str:
        if not self.path.exists() or self.path.stat().st_size == 0:
            return "GENESIS"
        last = None
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if line.strip(): last = json.loads(line)
        return last["hash"] if last else "GENESIS"

    def append(self, event_type: str, payload: Dict[str, Any]) -> str:
        event = {"ts": utc_now(), "event": event_type, "prev_hash": self._last_hash(), "payload": payload}
        event["hash"] = hashlib.sha256(canonical_json(event).encode()).hexdigest()
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")
        return event["hash"]

    def verify(self) -> List[str]:
        issues: List[str] = []
        prev = "GENESIS"
        if not self.path.exists(): return issues
        for idx, line in enumerate(self.path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip(): continue
            record = json.loads(line)
            h = record.pop("hash")
            if record.get("prev_hash") != prev:
                issues.append(f"line {idx}: prev_hash mismatch")
            expected = hashlib.sha256(canonical_json(record).encode()).hexdigest()
            if h != expected:
                issues.append(f"line {idx}: hash mismatch")
            prev = h
        return issues
