from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Literal, Optional

RuntimeStatus = Literal["PASS", "PATCH", "ESCALATE"]
ManualState = Literal["OPEN", "UNDER_REVIEW", "PATCH_REQUESTED", "APPROVED", "REJECTED"]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class ProvenanceRef:
    source: str
    locator: str = ""
    captured_at: str = field(default_factory=utc_now)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TruthRecord:
    id: str
    claim: str
    evidence: str
    source: str
    confidence: float = 1.0
    valid_until: Optional[str] = None
    provenance: List[ProvenanceRef] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ReasoningFrame:
    intent: str
    constraints: List[str] = field(default_factory=list)
    authority: List[str] = field(default_factory=list)
    success_criteria: List[str] = field(default_factory=list)
    assumptions: List[str] = field(default_factory=list)
    options_considered: List[str] = field(default_factory=list)


@dataclass
class MemoryRecord:
    id: str
    summary: str
    rationale: str = ""
    outcome: str = ""
    timestamp: str = field(default_factory=utc_now)
    related_ids: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CoherenceContext:
    truth: List[TruthRecord]
    reasoning: ReasoningFrame
    memory: List[MemoryRecord] = field(default_factory=list)
    world_state: Dict[str, Any] = field(default_factory=dict)
    mission_id: str = ""
    episode_id: str = ""


@dataclass
class ReviewResult:
    status: RuntimeStatus
    confidence: float
    unsupported_claims: List[str] = field(default_factory=list)
    contradictions: List[str] = field(default_factory=list)
    authority_issues: List[str] = field(default_factory=list)
    drift_signals: List[str] = field(default_factory=list)
    patch_instructions: List[str] = field(default_factory=list)
    rationale: str = ""


@dataclass
class RuntimeResult:
    status: RuntimeStatus
    applied: bool
    candidate: str
    final: Optional[str]
    review: ReviewResult
    ledger_hash: str
    manual_case_id: Optional[str] = None
    diagnostics: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ManualCerpaCase:
    case_id: str
    created_at: str
    state: ManualState
    trigger: str
    prompt: str
    candidate: str
    review: ReviewResult
    authority_required: bool = True
    operator_note: str = ""
    final_response: Optional[str] = None
    decided_at: Optional[str] = None


def to_plain(obj: Any) -> Any:
    if hasattr(obj, "__dataclass_fields__"):
        return asdict(obj)
    return obj
