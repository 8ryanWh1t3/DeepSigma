from __future__ import annotations
import json
from dataclasses import asdict
from pathlib import Path
from typing import Optional
from .models import CoherenceContext, TruthRecord, ReasoningFrame, MemoryRecord, ProvenanceRef


def load_context(path: str | Path) -> CoherenceContext:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    truth = []
    for item in raw.get("truth", []):
        item = dict(item)
        item["provenance"] = [ProvenanceRef(**x) for x in item.get("provenance", [])]
        truth.append(TruthRecord(**item))
    return CoherenceContext(
        truth=truth,
        reasoning=ReasoningFrame(**raw["reasoning"]),
        memory=[MemoryRecord(**x) for x in raw.get("memory", [])],
        world_state=raw.get("world_state", {}),
        mission_id=raw.get("mission_id", ""),
        episode_id=raw.get("episode_id", ""),
    )


def dump_context(ctx: CoherenceContext) -> str:
    return json.dumps(asdict(ctx), indent=2, ensure_ascii=False)
