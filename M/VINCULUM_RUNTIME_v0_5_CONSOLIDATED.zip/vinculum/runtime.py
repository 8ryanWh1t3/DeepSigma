from __future__ import annotations
import json
from dataclasses import asdict
from pathlib import Path
from typing import Optional
from .core.models import CoherenceContext, ReviewResult, RuntimeResult
from .core.ledger import HashLedger
from .deep_sigma.coherence import TRMEvaluator
from .deep_sigma.escalation import EscalationPolicy
from .deep_sigma.manual_cerpa import ManualCerpaQueue
from .meridian.coordinates import as_dict as coordinate_dict
from .adapters.base import ModelAdapter

class VinculumRuntime:
    def __init__(self, adapter: ModelAdapter, ledger_path: str|Path="vinculum_runtime_ledger.jsonl", manual_queue_path: str|Path="vinculum_manual_cerpa.jsonl", min_auto_apply_confidence: float=0.80, auditor_model: Optional[str]=None):
        self.adapter=adapter; self.ledger=HashLedger(ledger_path); self.manual=ManualCerpaQueue(manual_queue_path)
        self.trm=TRMEvaluator(); self.escalation=EscalationPolicy(min_auto_apply_confidence); self.auditor_model=auditor_model

    def _system(self, ctx: CoherenceContext)->str:
        governed=json.dumps(asdict(ctx),indent=2,ensure_ascii=False)
        coords=json.dumps(coordinate_dict(),indent=2)
        return f"""You are an inference engine operating inside VINCULUM Runtime.
VINCULUM surrounds the model. Deep Sigma governs what crosses the boundary.
Maintain Truth, Reasoning, and Memory coherence. Do not invent evidence or authority.
Maintain MERIDIAN coordinates and identify material orientation/navigation/guidance gaps.
Never self-authorize consequential changes to mission intent, policy, authority, or risk acceptance.
MERIDIAN COORDINATES:
{coords}
GOVERNED CONTEXT:
{governed}"""

    def _review(self, prompt: str, candidate: str, ctx: CoherenceContext)->ReviewResult:
        schema={"type":"json_schema","json_schema":{"name":"coherence_review","schema":{"type":"object","additionalProperties":False,"properties":{
            "status":{"type":"string","enum":["PASS","PATCH","ESCALATE"]},"confidence":{"type":"number"},
            "unsupported_claims":{"type":"array","items":{"type":"string"}},"contradictions":{"type":"array","items":{"type":"string"}},
            "authority_issues":{"type":"array","items":{"type":"string"}},"drift_signals":{"type":"array","items":{"type":"string"}},
            "patch_instructions":{"type":"array","items":{"type":"string"}},"rationale":{"type":"string"}},
            "required":["status","confidence","unsupported_claims","contradictions","authority_issues","drift_signals","patch_instructions","rationale"]}}}
        audit=f"Review for Truth, Reasoning, Memory, provenance, drift, authority, and mission-intent coherence.\nREQUEST:{prompt}\nCANDIDATE:{candidate}\nCONTEXT:{json.dumps(asdict(ctx),ensure_ascii=False)}"
        try:
            raw=self.adapter.complete("You are Deep Sigma's model-adjacent coherence reviewer.",audit,temperature=0,response_format=schema,model=self.auditor_model).content
            return ReviewResult(**json.loads(raw))
        except Exception as exc:
            return ReviewResult("ESCALATE",0.0,drift_signals=["REVIEWER_FAILURE"],rationale=f"fail closed: {type(exc).__name__}")

    def _manual(self, trigger: str, prompt: str, candidate: str, review: ReviewResult, diagnostics: dict)->RuntimeResult:
        case=self.manual.open(trigger,prompt,candidate,review)
        h=self.ledger.append("MANUAL_CERPA_OPENED",{"case_id":case.case_id,"trigger":trigger})
        return RuntimeResult("ESCALATE",False,candidate,None,review,h,case.case_id,diagnostics)

    def execute(self, prompt: str, ctx: CoherenceContext)->RuntimeResult:
        trm=self.trm.evaluate(ctx); diagnostics={"trm":asdict(trm),"meridian_coordinates":coordinate_dict()}
        self.ledger.append("CLAIM_CONTEXT",{"prompt":prompt,"diagnostics":diagnostics,"context":asdict(ctx)})
        if not trm.coherent:
            review=ReviewResult("ESCALATE",1.0,contradictions=trm.issues,drift_signals=["PREFLIGHT_COHERENCE_GAP"],rationale="deterministic preflight failed")
            return self._manual("preflight:"+",".join(trm.issues),prompt,"",review,diagnostics)
        candidate=self.adapter.complete(self._system(ctx),prompt).content
        self.ledger.append("EVENT_INFERENCE",{"candidate":candidate})
        review=self._review(prompt,candidate,ctx); self.ledger.append("REVIEW",asdict(review))
        if review.status=="PATCH":
            patch_prompt=f"Repair only these coherence defects without adding evidence or authority: {json.dumps(asdict(review))}\nCANDIDATE:{candidate}"
            patched=self.adapter.complete("You are the PATCH stage. Do not broaden authority.",patch_prompt,temperature=0).content
            self.ledger.append("PATCH",{"patched":patched}); review2=self._review(prompt,patched,ctx); self.ledger.append("REVIEW_PATCHED",asdict(review2))
            esc=self.escalation.evaluate(review2,ctx)
            if esc.required or review2.status!="PASS": return self._manual(";".join(esc.reasons) or "patch_not_pass",prompt,patched,review2,diagnostics)
            h=self.ledger.append("APPLY_AUTO",{"final":patched}); return RuntimeResult("PASS",True,candidate,patched,review2,h,None,diagnostics)
        esc=self.escalation.evaluate(review,ctx)
        if esc.required: return self._manual(";".join(esc.reasons),prompt,candidate,review,diagnostics)
        if review.status=="PASS":
            h=self.ledger.append("APPLY_AUTO",{"final":candidate}); return RuntimeResult("PASS",True,candidate,candidate,review,h,None,diagnostics)
        return self._manual("unresolved",prompt,candidate,review,diagnostics)
