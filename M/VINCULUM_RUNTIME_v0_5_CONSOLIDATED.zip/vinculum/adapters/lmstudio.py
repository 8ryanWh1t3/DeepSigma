from .openai_compatible import OpenAICompatibleAdapter

class LMStudioAdapter(OpenAICompatibleAdapter):
    def __init__(self, model: str, base_url: str="http://localhost:1234/v1", api_key: str="lm-studio"):
        super().__init__(model, base_url, api_key)
