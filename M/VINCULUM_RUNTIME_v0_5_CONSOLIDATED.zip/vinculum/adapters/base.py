from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol

@dataclass
class ModelResponse:
    content: str
    model: str
    latency_ms: Optional[float]=None
    raw: Dict[str,Any]=field(default_factory=dict)

class ModelAdapter(Protocol):
    def list_models(self) -> List[str]: ...
    def complete(self, system: str, user: str, *, temperature: float=0.2, response_format: Optional[Dict[str,Any]]=None, model: Optional[str]=None) -> ModelResponse: ...
