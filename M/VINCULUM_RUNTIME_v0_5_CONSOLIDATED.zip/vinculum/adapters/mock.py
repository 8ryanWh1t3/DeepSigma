from __future__ import annotations
import json
from typing import Dict, Any, List, Optional
from .base import ModelResponse

class MockAdapter:
    def __init__(self, responses: List[str]): self.responses=list(responses); self.model="mock"
    def list_models(self)->List[str]: return ["mock"]
    def complete(self, system: str, user: str, *, temperature: float=0.2, response_format: Optional[Dict[str,Any]]=None, model: Optional[str]=None)->ModelResponse:
        if not self.responses: raise RuntimeError("no mock responses")
        return ModelResponse(self.responses.pop(0), model or self.model, 0.0, {})
