# Architecture — Deep Sigma / VINCULUM pyLib 0.8.2

## Execution boundary

```text
INPUT / evidence / governed context
        ↓
VINCULUM representation + Fold episode
        ↓
JIT four-lens inspection
        ↓
model generation / review / optional patch
        ↓
READY_FOR_AUTHORITY
        ↓
attributable human decision from immutable startup roster
        ↓
APPLIED (host-recorded)
        ↓
POST_APPLY_CHECK
        ↓
LESSON / memory record
        ↓
CLOSED
```

No model-generated output reaches APPLY inside `VinculumRuntime.execute()`.

## Product boundaries

- **VINCULUM core/pipeline**: bounded representation and selected-pair analysis.
- **Navigable Fold**: immutable/versioned episodes, traversal and replay.
- **Runtime harness**: model-adjacent generation/review routed to human authority.
- **PATHFINDER / RESONATOR / COMPOSER**: typed integration stubs only.
- **CERPA**: lifecycle names and manual authority workflow; external Core bridge is optional and refuses to run without a verified `HumanApproval`.

## JIT

JIT is four independent lenses: Legacy of Precision, Density of Exposure, Matrix of Awareness, Ontological Grade. No composite readiness score exists.

## Memory

Canonical memory artifacts remain DLR, RS, DS and MG. This release provides links, episodes, lessons and replay structures; it does not claim to generate a complete enterprise DLR/RS/DS/MG suite.

## v0.8.2 additions

- model-endpoint containment contract;
- portable ledger anchors;
- immutable startup approver roster;
- post-Apply closure state machine;
- neutral VINCULUM Graph naming.
