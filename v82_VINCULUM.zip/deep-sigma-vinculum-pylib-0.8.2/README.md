# Deep Sigma / VINCULUM pyLib 0.8.2

**Candidate hardening + containment release.** This build absorbs the full 0.8.1 authority/fail-closed backlog and adds the first bounded 0.8.2 containment and external-anchor interfaces.

## Canonical architecture

```text
Semantic Folding Maximum
  TIME · WORDS · NUMBERS
        ↓
Journey Into Truth — four independent lenses
  Legacy of Precision
  Density of Exposure
  Matrix of Awareness
  Ontological Grade
        ↓
VINCULUM World
  Studio = author/assess
  VINCULUM = inspect/compare/replay (read-only)
        ↓
PATHFINDER / RESONATOR / COMPOSER  [interface stubs only]
        ↓
CERPA
  Claim → Event → Review → Patch → Apply → Post-Apply Check → Lesson
        ↓
DLR / RS / DS / MG
```

**PATHFINDER, RESONATOR and COMPOSER are not implemented in this wheel.** The package carries only typed interface contracts and architecture vocabulary for integration with those products.

## Authority boundary

v0.8.2 removes all runtime `APPLY_AUTO` paths. A model may generate, patch and review a candidate, but a passing candidate becomes `READY_FOR_AUTHORITY`, not applied.

A human decision must:

1. name an actor;
2. resolve that actor through a read-only startup `ApproverRoster`;
3. write the decision to the hash ledger;
4. record Apply separately;
5. record a post-Apply observation; and
6. record a lesson/memory object before the case can close.

The library validates roster membership; the host remains responsible for authenticating the real-world person behind the actor ID.

## Scoring posture

This release removes universal object/composite score surfaces (`Sigma_V`, `vinculum_score`, `usable_value`, `tension_index`, weighted mean collision, JIT readiness, and team-average coherence). The library preserves separate channels, counts, maxima, pair status, explicit deltas, conflict/coverage and provenance. None of those fields is truth, risk, readiness, permission or authority.

## Containment and anchors (new in 0.8.2)

- model endpoints: HTTPS or loopback HTTP only; `file://` and remote clear-text HTTP are refused;
- prompt and response length bounds;
- `HashLedger.tip()` and `verify(expected_tip=..., expected_length=...)`;
- portable `LedgerAnchor` checkpoints that an external trusted system may retain or sign;
- runtime/queue files created with restricted permissions where the OS supports them.

These are host-facing controls, **not an OS sandbox** and not a substitute for VM/container/HSM/KMS controls.

## Installation

```bash
python -m pip install dist/vinculum_pylib-0.8.2-py3-none-any.whl
```

Optional test environment:

```bash
python -m pip install '.[test,api,documents,pdf,parquet]'
```

## Commands

```text
vinculum inspect ...        bounded object/channel inspection; no universal score
vinculum-graph ...          explicit cross-order graph/hinge evaluation
vinculum-pipeline ...       declarative INPUT → RUNTIME → OUTPUT pipeline
vinculum-fold ...           Navigable Fold episode/replay utilities
vinculum-runtime ...        model-adjacent runtime; no automatic Apply
```

The old `vinculum score`/`score-json` command names remain hidden compatibility aliases, but their output no longer contains the removed composite score families.

## Product-neutral naming

The former `vinculum-lattice` command and `LatticeDB` wording were retired. `VINCULUM Graph` is the neutral relationship surface and does not imply integration with Anduril Lattice.

## Scope exclusions

The wheel does not include:

- C-UAS scenario/demo material;
- a DoD autonomy compliance profile;
- the separate `deepsigma==2.1.3` package;
- live vendor integrations;
- command/sensor actuation;
- production IAM;
- certification of truth, safety, legality, compliance or mission readiness.

See `SECURITY.md`, `ARCHITECTURE.md`, `ACCEPTANCE.md`, and `RELEASE.json`.
