# Declared semantic delta — 0.8.0 → 0.8.2

1. Runtime PASS no longer means Apply. It means a candidate is eligible to enter human authority review.
2. APPLY is not closure. Closure requires observed outcome plus a lesson/memory record.
3. JIT dimensions are independent lenses, not a composite readiness score.
4. Universal object/composite scores are removed from current public output.
5. Authority supplied inside candidate/world/model content is not trusted authority.
6. The canonical organizational loop is Truth → Decision → Outcome → Drift → Reflection → Patch → Memory; the mission-autonomy loop is a separate application loop.
7. VINCULUM Graph is product-neutral and does not imply vendor Lattice integration.
