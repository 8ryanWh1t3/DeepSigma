# Graphic traceability — v0.8.2

Historical concept graphics are retained under `docs/` as design provenance only. Names or integrations depicted there do not prove implementation. Current executable product boundaries are defined by README, ARCHITECTURE, SECURITY and RELEASE.json.
