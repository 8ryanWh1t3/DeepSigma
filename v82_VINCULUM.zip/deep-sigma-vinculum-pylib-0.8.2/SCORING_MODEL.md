# Channel and relationship model — v0.8.2

The library no longer exposes a universal object score.

Allowed outputs include separate declared/derived P and D channels, coverage, signed channel direction, pair status, explicit numeric delta/range relation, conflict/partial/unresolved/not-comparable states, counts, maxima, evidence coverage and provenance.

Removed public composites include `Sigma_V`, `vinculum_score`, `usable_value`, `tension_index`, conflict-adjusted usable value, weighted mean raw collision score, team-average coherence and JIT readiness.

A high or low channel value does **not** establish truth, risk, safety, readiness, authority or permission.
