# Migration 0.8.0 → 0.8.2

## Breaking safety changes

- `VinculumRuntime.execute()` never applies a candidate; callers must process the returned manual case.
- `ManualCerpaQueue.decide()` requires keyword `actor=` and an immutable startup roster.
- a case requires `record_applied()` then `close_after_observation()` to reach CLOSED.
- JIT `readiness()` is removed.
- public composite score fields are removed.
- `vinculum-lattice` becomes `vinculum-graph`.
- the DoD autonomy profile and C-UAS example are not shipped.

These changes are deliberate authority/scope corrections.
