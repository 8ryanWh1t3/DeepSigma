# PyLib 0.8.1 change list (internal; covered by the 13:15 Oct 3 hold)
Items 1-17 are from Tony, 18-19 from Steve, 20-21 from F.R.I.D.A.Y., 22-24 from Elon. The list was closed at 24 by Steve (12:49 ET); later finds go to 0.8.2, except any new way to self-apply or self-approve, which blocks a lock regardless. (Sunday Oct 4 2026, 12:48 ET). Full text is in the Deep Sigma room; the build spec is /workspace/pylib-lock/CLAUDE_EVAL_CHECK.md.
1. AI self-apply: remove APPLY_AUTO (runtime.py lines 66 and 70).
2. CoreCerpaBridge.run applies with no authorizer: refuse without a recorded human approval.
3. Caller-supplied authority accepted (multi_agent, dod_autonomy, CandidateTest.authorized default): trusted state, or deny with AUTHORITY_MISSING.
4. An empty authority list auto-applies: deny.
5. decide() has no identity check, actor or ledger record: check against a startup roster no call can change; record the actor; identity stays Targeted.
6. Four composite score families (vinculum_score/usable_value/tension_index/Sigma_V; weighted_mean_raw_collision_score; coherence_score team average; readiness()): remove; keep the max and the counts.
7. Reviewer input not validated (NaN, 7.0, string): validate and fail closed.
8. Consequence flags only count when literally True: anything not absent or false escalates.
9. A failed model call leaves no record: write RUNTIME_FAILED and open a manual case.
10. Ledger race and truncation: file lock, fsync, retained tip, tolerate a torn line.
11. An expired truth reports coherent: make it incoherent.
12. Lattice naming: rename the vinculum-lattice command, lattice_cli and LatticeDB wording.
13. Drop the C-UAS example and DoD profile from the wheel (Axiom 1).
14. Regenerate the demo from 0.8.1 (the shipped one was made by 0.7.0).
15. Flip the test_runtime.py test that expects applied=True from an AI review.
16. Smaller fixes: file:// model URL, double-decide lock, file permissions, PyYAML test dependency, SECURITY.md and build notes at 0.7.0, VALIDATION.md skip count.
17. Acceptance: Claude's 30 tests (license test waits on Boss) plus our 8 gates, run on the installed wheel with no src/ next to it.
18. README: label PATHFINDER, RESONATOR and COMPOSER as stubs; no claim to implement them.
19. RELEASE.json: say "candidate" until Boss locks; the recorded date is the lock date.
20. Manifest wording: call MANIFEST.json and MANIFEST.sha256 a hash list everywhere, never "signed". The lock is the hash F.R.I.D.A.Y records in P3.
21. Every gate test must fail on 0.8.0 (zip 5ccdf80a) and pass on the exact 0.8.1 file; both runs kept as evidence.
22. Roster write access: the approver roster is read-only to the runtime; a test shows a runtime write to it is refused.
23. Per-object scorers in scorers.py (score_language, score_math, others) feeding the banned scores: remove; any kept for the pairwise model needs a written reason it produces no single per-object number.
24. APPLIED is not closure: if a case ends at APPLIED, add a post-apply check event and a lesson record; a case isn't done without both.
Out until Boss calls them: the LICENSE, and deepsigma==2.1.3 (keep that package off the box).
