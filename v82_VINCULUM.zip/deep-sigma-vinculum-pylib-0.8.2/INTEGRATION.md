# Integration contract — v0.8.2

- `vinculum`: bounded object/channel inspection compatibility surface.
- `vinculum-graph`: explicit selected-pair cross-order graph evaluation.
- `vinculum-pipeline`: configured local-file orchestration.
- `vinculum-fold`: Navigable Fold episode/replay surface.
- `vinculum-runtime`: model-adjacent candidate/review surface; no automatic Apply.

PATHFINDER, RESONATOR and COMPOSER are interface stubs only. The optional external Deep Sigma Core CERPA bridge is not bundled and refuses to execute without a verified `HumanApproval`.
