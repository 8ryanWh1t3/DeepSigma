# Hinge contract — v0.8.2

A hinge exists only for an explicitly selected pair of representations. Comparability gates, discrepancy, support, coverage and provenance remain distinct. Unpaired material is not agreement. No aggregate score grants authority.
