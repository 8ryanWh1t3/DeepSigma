# Security and trust boundaries — v0.8.2

## Non-negotiable boundary

**Models do not authorize consequential Apply.** `VinculumRuntime.execute()` can only produce a manual CERPA case. A clean candidate returns `READY_FOR_AUTHORITY` with `applied=False`.

## Reviewer parsing

Reviewer output is strict JSON. Confidence must be a real finite number in `[0,1]`; NaN, Infinity, strings, booleans and out-of-range values fail closed. Wrong field types or shapes fail closed to the manual queue.

## Consequence flags

For the declared consequence flags, any value other than absent/`None`/`False` is treated as asserted and escalates.

## Human authority

Human decisions require an `actor` present in a read-only startup `ApproverRoster` and, when supplied, the required authority string. The library records the actor, roster hash and decision in the hash ledger. The host is responsible for IAM/authentication of that actor ID.

## Ledger

The JSONL ledger uses an advisory cross-process lock around append, flush and `fsync`. `tip()` returns `(length, hash)`. `verify(expected_tip=..., expected_length=...)` detects edits, broken chaining, truncation relative to a retained anchor, and malformed/torn final records without raising.

The ledger is **tamper-evident, not immutable and not a trust anchor**. Retain/sign anchors outside the process for stronger guarantees.

## Manual queue

Manual decision updates use the same process lock. A case cannot be decided twice from a valid current state. Runtime/queue files are created with restricted permissions where supported.

## Model endpoint

The OpenAI-compatible adapter accepts HTTPS or loopback HTTP only. `file://` and remote clear-text HTTP are rejected. Prompt/response size limits are enforced by the containment policy.

## Apply and closure

Approval and Apply are separate records. An APPLIED case cannot close until a post-Apply observation and lesson record are written.

## Not claimed

No production IAM, HSM/KMS binding, signed manifests, OS sandbox, penetration certification, mission authorization, legal/compliance determination, truth oracle, or automatic command action is provided.
