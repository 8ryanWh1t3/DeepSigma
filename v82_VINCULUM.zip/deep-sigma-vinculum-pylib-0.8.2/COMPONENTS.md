# Components — v0.8.2

| Component | Role | Status |
|---|---|---|
| `vinculum` | bounded channel inspection, cross-order selected-pair analysis, pipeline | implemented |
| `vinculum_folding` | Navigable Fold episodes, replay, traversal | implemented |
| `vinculum.runtime_harness` | model-adjacent review routed to human authority | implemented, no auto-Apply |
| PATHFINDER port | navigation contract | stub/interface only |
| RESONATOR port | semantic comparison contract | stub/interface only |
| COMPOSER port | governed-change proposal contract | stub/interface only |
| external Deep Sigma Core CERPA | optional bridge | not bundled |
