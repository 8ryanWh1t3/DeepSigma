# Versioning

- **0.8.0** — frozen negative baseline / HOLD. Do not modify.
- **0.8.1** — hardening backlog identifier; changes rolled into 0.8.2, not separately shipped.
- **0.8.2** — candidate hardening + containment build.

A future lock records the exact candidate ZIP SHA-256. `RELEASE.json` remains `candidate` until that lock occurs.
