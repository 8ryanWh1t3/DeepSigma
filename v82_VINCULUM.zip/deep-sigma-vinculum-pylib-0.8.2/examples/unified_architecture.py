"""Print the canonical architecture inventory without invoking a model."""
import json

from vinculum import AUTHORITY_RULE, CANONICAL_MAXIM, canonical_inventory


if __name__ == "__main__":
    print(CANONICAL_MAXIM)
    print(AUTHORITY_RULE)
    print(json.dumps(canonical_inventory(), indent=2))
