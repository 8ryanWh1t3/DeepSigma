# Pairing monitor — v0.8.2

The monitor proposes candidate representation pairs only. It does not pair by numeric closeness, establish truth, or authorize evaluation/action.

```bash
vinculum-graph monitor examples/monitor_events.jsonl
```
