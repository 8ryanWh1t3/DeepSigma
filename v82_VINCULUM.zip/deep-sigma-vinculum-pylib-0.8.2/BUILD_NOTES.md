# Build notes — Deep Sigma / VINCULUM pyLib v0.8.2

## Release intent

0.8.2 is the first candidate after the 0.8.0 external gate review. It absorbs the entire 0.8.1 hardening backlog before adding bounded containment/anchor interfaces.

## Hardening delta

- removed APPLY_AUTO;
- immutable startup approver roster + actor-attributed manual decisions;
- strict review/threshold validation;
- fail-closed runtime failures with terminal ledger event;
- concurrency-safe ledger with retained-tip verification;
- expired truth and missing authority are coherence failures;
- no JIT readiness composite;
- removed public object composite score families and cross-order weighted mean;
- removed C-UAS and DoD profile from current wheel;
- renamed Lattice-named CLI/surface to VINCULUM Graph;
- APPLIED requires post-Apply check + lesson before CLOSED;
- regenerated release docs/demos and corrected test dependency surface.

## New 0.8.2 capability

- `ContainmentPolicy` for endpoint and payload boundaries;
- `LedgerAnchor` for external retention/signing workflows;
- canonical Coherence Ops loop declared separately from mission-autonomy loop.
