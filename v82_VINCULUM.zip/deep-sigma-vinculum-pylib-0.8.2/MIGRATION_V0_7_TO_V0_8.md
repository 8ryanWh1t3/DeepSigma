# Migration from 0.7 to 0.8

Existing `vinculum` imports and CLI commands remain available. New capabilities are additive:

```python
from vinculum import canonical_inventory
from vinculum_folding import FoldEpisode
from vinculum.runtime_harness.runtime import VinculumRuntime
```

The former `vinculum-folding` and `vinculum-runtime` distributions are no longer required when using the unified wheel. Do not install the old runtime package over this distribution because both historically used the `vinculum` import name.

The Fold adapter accepts serialized VINCULUM engine versions 0.7.0 and 0.8.0. It remains read-only and does not re-evaluate pipeline results.
