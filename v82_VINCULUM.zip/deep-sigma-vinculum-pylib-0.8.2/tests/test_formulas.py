import unittest
from vinculum import derive_vector

class FormulaTests(unittest.TestCase):
    def test_equal_pd_is_boundary(self):
        v=derive_vector(.5,.5,1.0)
        self.assertAlmostEqual(v.signed_relation,0.0)
        self.assertAlmostEqual(v.balance,1.0)
    def test_p_dominant(self): self.assertLess(derive_vector(.8,.2,1).signed_relation,0)
    def test_d_dominant(self): self.assertGreater(derive_vector(.2,.8,1).signed_relation,0)
    def test_zero_total_neutral(self): self.assertEqual(derive_vector(0,0,0).signed_relation,0)
    def test_no_composite_fields(self):
        v=derive_vector(.8,.2,.5)
        for name in ('vinculum_score','usable_value','effective_tension','tension_index'):
            self.assertFalse(hasattr(v,name))
    def test_ranges(self):
        for P in [0,.1,.5,1]:
            for D in [0,.1,.5,1]:
                v=derive_vector(P,D,.7)
                self.assertTrue(-1<=v.signed_relation<=1)
                self.assertTrue(0<=v.balance<=1)
                self.assertTrue(0<=v.intensity<=1)
if __name__=='__main__': unittest.main()
