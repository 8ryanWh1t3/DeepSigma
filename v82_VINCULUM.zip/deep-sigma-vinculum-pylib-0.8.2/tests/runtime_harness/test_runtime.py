import json
from vinculum.runtime_harness.adapters.mock import MockAdapter
from vinculum.runtime_harness.runtime import VinculumRuntime
from vinculum.runtime_harness.core.models import TruthRecord,ReasoningFrame,MemoryRecord,CoherenceContext
from vinculum.runtime_harness.core.authority import Approver,ApproverRoster

def good_ctx(**world):
    return CoherenceContext([TruthRecord("t","truth","evidence","source")],ReasoningFrame("intent",["constraint"],["human"]),[MemoryRecord("m","memory")],world)

def review(status="PASS",confidence=.95):
    return json.dumps({"status":status,"confidence":confidence,"unsupported_claims":[],"contradictions":[],"authority_issues":[],"drift_signals":[],"patch_instructions":[],"rationale":"ok"})

def roster(): return ApproverRoster([Approver("human",("human",))],source_hash="test")

def test_runtime_pass_routes_to_human_authority(tmp_path):
    a=MockAdapter(["candidate",review()]); rt=VinculumRuntime(a,tmp_path/"l.jsonl",tmp_path/"q.jsonl",approver_roster=roster())
    r=rt.execute("prompt",good_ctx()); assert not r.applied and r.status=="READY_FOR_AUTHORITY" and r.manual_case_id

def test_runtime_manual_for_consequence(tmp_path):
    a=MockAdapter(["candidate",review()]); rt=VinculumRuntime(a,tmp_path/"l.jsonl",tmp_path/"q.jsonl",approver_roster=roster())
    r=rt.execute("prompt",good_ctx(consequential_action=True)); assert not r.applied and r.manual_case_id

def test_apply_requires_approval_and_post_apply_closure(tmp_path):
    rt=VinculumRuntime(MockAdapter(["candidate",review()]),tmp_path/"l.jsonl",tmp_path/"q.jsonl",approver_roster=roster())
    r=rt.execute("prompt",good_ctx()); cid=r.manual_case_id
    c=rt.manual.decide(cid,"approve",actor="human",authority="human"); assert c.state=="APPROVED"
    c=rt.manual.record_applied(cid,actor="human",authority="human"); assert c.state=="APPLIED"
    c=rt.manual.close_after_observation(cid,actor="human",authority="human",observed_outcome="matched",expected_state_met=True,lesson_record_id="RS-1")
    assert c.state=="CLOSED" and c.lesson_record_id=="RS-1"
