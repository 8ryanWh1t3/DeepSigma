from vinculum.runtime_harness.meridian.coordinates import AXES, validate

def test_coordinates():
    assert validate()==[]
    assert [(x.primitive,x.pillar,x.function) for x in AXES]==[("TIME","MEMORY","ORIENTATION"),("LANGUAGE","REASONING","NAVIGATION"),("MATH","TRUTH","GUIDANCE")]

