from vinculum.runtime_harness.integrations.trinity import TRINITY_RULE
from vinculum.runtime_harness.integrations.nano_sigma import NANO_SIGMA_FORMULA
from vinculum.runtime_harness.lineage.jit import JITDimensions

def test_integration_contracts_and_jit_four_lenses():
    assert "PATHFINDER" in TRINITY_RULE and NANO_SIGMA_FORMULA=="Trinity + VINCULUM Graph + SQLite"
    d=JITDimensions(1,1,1,1)
    assert set(d.as_dict())=={"legacy_of_precision","density_of_exposure","matrix_of_awareness","ontological_grade"}
    assert not hasattr(d,"readiness")
