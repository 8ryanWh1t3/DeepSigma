from vinculum.runtime_harness.deep_sigma.manual_cerpa import ManualCerpaQueue
from vinculum.runtime_harness.deep_sigma.escalation import EscalationPolicy
from vinculum.runtime_harness.core.models import ReviewResult, CoherenceContext, ReasoningFrame
from vinculum.runtime_harness.core.authority import Approver,ApproverRoster
from vinculum.runtime_harness.core.ledger import HashLedger

def test_manual_queue(tmp_path):
    roster=ApproverRoster([Approver("alice",("approver",))],source_hash="h")
    ledger=HashLedger(tmp_path/"l.jsonl"); q=ManualCerpaQueue(tmp_path/"q.jsonl",roster=roster,ledger=ledger); r=ReviewResult("PASS",.95)
    c=q.open("test","p","candidate",r); assert c.state=="OPEN"
    assert q.decide(c.case_id,"approve",actor="alice",authority="approver").state=="APPROVED"
    assert any(json_line for json_line in (tmp_path/"l.jsonl").read_text().splitlines() if "MANUAL_CERPA_DECIDED" in json_line)

def test_consequential_escalates():
    c=CoherenceContext([],ReasoningFrame("x"),world_state={"consequential_action":"true"})
    d=EscalationPolicy().evaluate(ReviewResult("PASS",.99),c); assert d.required
