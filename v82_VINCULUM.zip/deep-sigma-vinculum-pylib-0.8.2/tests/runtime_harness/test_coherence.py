from vinculum.runtime_harness.core.models import TruthRecord, ReasoningFrame, MemoryRecord, CoherenceContext
from vinculum.runtime_harness.deep_sigma.coherence import TRMEvaluator

def test_trm_good():
    c=CoherenceContext([TruthRecord("t","x","e","s")],ReasoningFrame("intent",["c"],["human"]),[MemoryRecord("m","s")])
    assert TRMEvaluator().evaluate(c).coherent

def test_trm_bad():
    c=CoherenceContext([],ReasoningFrame("",[]),[])
    r=TRMEvaluator().evaluate(c); assert not r.coherent and "TRUTH_GAP" in r.issues

