from vinculum.runtime_harness.meridian.degraded_ops import ConnectivityState, can_transition, reconcile

def test_transitions():
    assert can_transition(ConnectivityState.DISCONNECTED,ConnectivityState.REJOINING)
    assert not can_transition(ConnectivityState.DISCONNECTED,ConnectivityState.CONNECTED)

def test_reconcile_conflicts():
    r=reconcile({"truth":{"a":1},"authority":{"x":"human"}},{"truth":{"a":2},"authority":{"x":"human"}})
    assert r.truth_conflicts==["a"] and not r.clean

