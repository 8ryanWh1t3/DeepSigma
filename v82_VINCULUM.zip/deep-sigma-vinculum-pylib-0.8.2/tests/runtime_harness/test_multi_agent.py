from vinculum.runtime_harness.meridian.multi_agent import AgentState, rollup
from vinculum.runtime_harness.core.authority import Approver,ApproverRoster

def test_team_rollup_requires_trusted_authority():
    intent="mission"; agents=[AgentState("a","sensor",intent,["observe"]),AgentState("b","planner",intent,["recommend"])]
    assert not rollup(agents,intent).mission_coherent
    roster=ApproverRoster([Approver("a",("observe",)),Approver("b",("recommend",))],source_hash="test")
    r=rollup(agents,intent,trusted_authority=roster); assert r.mission_coherent and r.agent_count==2
