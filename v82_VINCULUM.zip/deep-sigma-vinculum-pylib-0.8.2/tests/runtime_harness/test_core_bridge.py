from vinculum.runtime_harness.bridges.deepsigma_core import probe

def test_probe_is_nonfatal():
    r=probe(); assert {x.name for x in r}=={"CERPA","CoherenceGate","MemoryGraph","DriftSignal"}

