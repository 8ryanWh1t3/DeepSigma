from vinculum import (
    AUTHORITY_RULE, CLOSURE_RULE, CerpaStage, FoldAspect, JITLens, STUDIO, VIEWER,
    canonical_inventory,
)


def test_canonical_fold_and_jit_are_complete():
    inventory = canonical_inventory()
    assert inventory["fold_aspects"] == ("time", "words", "numbers")
    assert inventory["fold_operation"] == ("Distinguish", "Arrange", "Relate", "Continue")
    assert inventory["jit_lenses"] == (
        "Legacy of Precision", "Density of Exposure", "Matrix of Awareness",
        "Ontological Grade",
    )


def test_surfaces_preserve_authority_boundary():
    assert STUDIO.can_author is True and STUDIO.can_apply is False
    assert VIEWER.can_author is False and VIEWER.can_apply is False
    assert "Inspection is not authorization" in AUTHORITY_RULE
    assert "human authority" in AUTHORITY_RULE
    assert "APPLY is not closure" in CLOSURE_RULE


def test_cerpa_is_governed_sequence_not_jit_lens():
    assert tuple(stage.value for stage in CerpaStage) == (
        "Claim", "Event", "Review", "Patch", "Apply", "Post-Apply Check", "Lesson",
    )
    assert set(CerpaStage).isdisjoint(set(JITLens))
    assert set(FoldAspect).isdisjoint(set(JITLens))
