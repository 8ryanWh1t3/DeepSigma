# INPUT → RUNTIME → OUTPUT contract — v0.8.2

## INPUT
Bounded files/typed scenarios, explicit evidence/provenance, governed context, immutable startup authority roster, optional external ledger anchor.

## RUNTIME
Parse → represent → pair → evaluate → model candidate/review → deterministic preflight → manual CERPA authority. No model path may call Apply.

## OUTPUT
Inspection reports, pair findings, Fold episodes, manual authority cases, hash-ledger evidence, optional anchors, post-Apply observation and lesson records.

No output is truth, risk acceptance, command authority or successful mission outcome merely because it exists.
