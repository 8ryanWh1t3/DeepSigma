#!/usr/bin/env python3
"""v0.8.2-specific authority, containment, anchor and closure gates."""
from __future__ import annotations
import json, pathlib, tempfile, threading
from vinculum import VinculumEngine, ingest_text
from vinculum.matrix import PairGraph
from vinculum.runtime_harness.adapters.mock import MockAdapter
from vinculum.runtime_harness.containment import validate_model_url
from vinculum.runtime_harness.core.anchors import create_anchor, verify_anchor
from vinculum.runtime_harness.core.authority import Approver, ApproverRoster
from vinculum.runtime_harness.core.ledger import HashLedger
from vinculum.runtime_harness.core.models import CoherenceContext, MemoryRecord, ReasoningFrame, TruthRecord
from vinculum.runtime_harness.lineage.jit import JITDimensions
from vinculum.runtime_harness.runtime import VinculumRuntime


def review():
    return json.dumps({"status":"PASS","confidence":.95,"unsupported_claims":[],"contradictions":[],"authority_issues":[],"drift_signals":[],"patch_instructions":[],"rationale":"ok"})

def ctx():
    return CoherenceContext([TruthRecord("t","claim","e","s")],ReasoningFrame("intent",["constraint"],["human"]),[MemoryRecord("m","memory")])

def roster(): return ApproverRoster([Approver("alice",("human","apply"))],source_hash="roster-hash")

def run_gate(name,fn):
    try:
        fn(); print(f"PASS {name}"); return True
    except Exception as exc:
        print(f"FAIL {name}: {type(exc).__name__}: {exc}"); return False

def g_no_auto_apply():
    td=pathlib.Path(tempfile.mkdtemp()); rt=VinculumRuntime(MockAdapter(["candidate",review()]),td/"l",td/"q",approver_roster=roster())
    out=rt.execute("p",ctx())
    assert not out.applied and out.status=="READY_FOR_AUTHORITY" and "APPLY_AUTO" not in (td/"l").read_text()

def g_roster_immutable_unknown_denied():
    r=roster(); assert r.can_write() is False
    try:r.require("mallory","human")
    except Exception:pass
    else:raise AssertionError("unknown actor accepted")
    assert not hasattr(r.snapshot(),"__setitem__")

def g_human_decision_logged():
    td=pathlib.Path(tempfile.mkdtemp()); rt=VinculumRuntime(MockAdapter(["candidate",review()]),td/"l",td/"q",approver_roster=roster())
    out=rt.execute("p",ctx()); rt.manual.decide(out.manual_case_id,"approve",actor="alice",authority="human")
    text=(td/"l").read_text(); assert "MANUAL_CERPA_DECIDED" in text and "alice" in text

def g_apply_not_closure():
    td=pathlib.Path(tempfile.mkdtemp()); rt=VinculumRuntime(MockAdapter(["candidate",review()]),td/"l",td/"q",approver_roster=roster())
    out=rt.execute("p",ctx()); cid=out.manual_case_id
    rt.manual.decide(cid,"approve",actor="alice",authority="human")
    a=rt.manual.record_applied(cid,actor="alice",authority="apply"); assert a.state=="APPLIED"
    try: rt.manual.close_after_observation(cid,actor="alice",authority="human",observed_outcome="",expected_state_met=True,lesson_record_id="")
    except ValueError: pass
    else: raise AssertionError("closed without evidence/lesson")
    c=rt.manual.close_after_observation(cid,actor="alice",authority="human",observed_outcome="observed",expected_state_met=True,lesson_record_id="RS-1")
    assert c.state=="CLOSED"

def g_anchor():
    td=pathlib.Path(tempfile.mkdtemp()); l=HashLedger(td/"l"); l.append("A",{}); a=create_anchor(l,ledger_id="x"); assert verify_anchor(l,a)==[]; l.append("B",{}); assert verify_anchor(l,a)

def g_concurrent_ledger():
    td=pathlib.Path(tempfile.mkdtemp()); l=HashLedger(td/"l"); errs=[]
    def w():
        try:
            for _ in range(50): l.append("E",{})
        except Exception as e: errs.append(e)
    th=[threading.Thread(target=w) for _ in range(4)]; [t.start() for t in th]; [t.join() for t in th]
    assert not errs and l.tip()[0]==200 and l.verify()==[]

def g_containment():
    assert validate_model_url("http://localhost:1234/v1")
    assert validate_model_url("https://example.invalid/v1")
    for bad in ("file:///etc/passwd","http://8.8.8.8/v1"):
        try: validate_model_url(bad)
        except ValueError: pass
        else: raise AssertionError(f"accepted {bad}")

def g_no_jit_composite(): assert not hasattr(JITDimensions(1,1,1,1),"readiness")

def g_no_object_composites():
    d=VinculumEngine().inspect(ingest_text("maybe true",decompose=False)).to_dict(include_children=False)
    for k in ("Sigma_V","vinculum_score","usable_value","tension_index","reconciled_usable_value"): assert k not in d

def g_no_weighted_mean(): assert "weighted_mean_raw_collision_score" not in PairGraph().evaluate().summary

def main():
    gates=[
        ("A1_NO_AUTO_APPLY",g_no_auto_apply),("A2_IMMUTABLE_ROSTER",g_roster_immutable_unknown_denied),
        ("A3_ATTRIBUTED_DECISION",g_human_decision_logged),("A4_APPLY_NOT_CLOSURE",g_apply_not_closure),
        ("A5_EXTERNAL_ANCHOR",g_anchor),("A6_LEDGER_CONCURRENCY",g_concurrent_ledger),
        ("A7_ENDPOINT_CONTAINMENT",g_containment),("A8_JIT_NO_COMPOSITE",g_no_jit_composite),
        ("A9_OBJECT_NO_COMPOSITES",g_no_object_composites),("A10_NO_WEIGHTED_MEAN",g_no_weighted_mean),
    ]
    ok=sum(run_gate(*g) for g in gates); print(f"Summary: {ok}/{len(gates)} PASS"); return 0 if ok==len(gates) else 1

if __name__=="__main__": raise SystemExit(main())
