#!/usr/bin/env python3
"""Executable gates for VINCULUM / Deep Sigma pyLib 0.8.0 (evaluation of 2026-10-04).

Run against the INSTALLED wheel, from outside the source tree:

    python -m venv .venv && .venv/bin/pip install dist/vinculum_pylib-0.8.0-py3-none-any.whl
    .venv/bin/python vinculum_080_gate_probes.py --release-dir /path/to/deep-sigma-vinculum-pylib-0.8.0

Result codes
    PASS  the property holds
    FAIL  a defect: the property does not hold (the run exits 1 if any gate FAILs)
    HOLD  a Boss-decision item: behaviour reported, never fails the run
    SKIP  prerequisite missing (release dir, or the Phase I package)

Options
    --release-dir DIR   extracted release directory (file and example gates)
    --json PATH         also write the results as JSON (id, group, title, result, evidence)

The FAIL gates are written as acceptance tests: a 0.8.1 that closes the blocking
items should flip them to PASS without editing this file. The PASS gates are
regression guards for properties that held on 0.8.0.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib
import importlib.metadata as metadata
import inspect
import json
import pathlib
import random
import re
import subprocess
import sys
import tempfile
import threading
import time
from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple


class Skip(Exception):
    """Prerequisite missing."""


class Hold(Exception):
    """Boss-decision item: the message is the evidence."""


@dataclass
class Context:
    release_dir: Optional[pathlib.Path]


GATES: List[Tuple[str, str, str, Callable[[Context], Tuple[bool, str]]]] = []


def gate(gate_id: str, group: str, title: str):
    def register(fn):
        GATES.append((gate_id, group, title, fn))
        return fn
    return register


# ---------------------------------------------------------------- helpers

def review_json(status: str = "PASS", confidence=0.95, **extra) -> str:
    body = {"status": status, "confidence": confidence, "unsupported_claims": [],
            "contradictions": [], "authority_issues": [], "drift_signals": [],
            "patch_instructions": [], "rationale": "ok"}
    body.update(extra)
    return json.dumps(body)  # float('nan') serialises as NaN, which Python's json.loads accepts


def make_context(**world):
    from vinculum.runtime_harness.core.models import (
        CoherenceContext, MemoryRecord, ReasoningFrame, TruthRecord)
    return CoherenceContext(
        [TruthRecord("t", "claim", "evidence", "source")],
        ReasoningFrame("intent", ["constraint"], ["human"]),
        [MemoryRecord("m", "memory")], world)


def ledger_events(runtime) -> List[str]:
    path = runtime.ledger.path
    if not path.exists():
        return []
    return [json.loads(line)["event"]
            for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def run_runtime(responses, adapter=None, **world):
    from vinculum.runtime_harness.adapters.mock import MockAdapter
    from vinculum.runtime_harness.runtime import VinculumRuntime
    tmp = pathlib.Path(tempfile.mkdtemp())
    runtime = VinculumRuntime(adapter or MockAdapter(responses), tmp / "ledger.jsonl", tmp / "queue.jsonl")
    try:
        outcome = runtime.execute("prompt", make_context(**world))
    except Exception as exc:  # noqa: BLE001 - the escape is the evidence
        outcome = exc
    return runtime, outcome, ledger_events(runtime)


def applied(outcome) -> bool:
    return (not isinstance(outcome, Exception)) and bool(outcome.applied)


def describe(outcome, events) -> str:
    if isinstance(outcome, Exception):
        return f"{type(outcome).__name__} escaped execute(); ledger={events}"
    return f"status={outcome.status} applied={outcome.applied}; ledger={events}"


def need_release(ctx: Context) -> pathlib.Path:
    if ctx.release_dir is None:
        raise Skip("needs --release-dir")
    return ctx.release_dir


def pair_signature(report):
    return sorted((p.pair_id, p.status.value, json.dumps(p.discrepancy.get("signed_delta")),
                   p.raw_collision_score, p.supported_collision_score) for p in report.pairs)


def evaluate_scenario(data: dict):
    from vinculum import scenario_from_dict
    from vinculum.report import write_json
    report = scenario_from_dict(copy.deepcopy(data)).evaluate()
    path = pathlib.Path(tempfile.mkdtemp()) / "report.json"
    write_json(report, path)
    return report, hashlib.sha256(path.read_bytes()).hexdigest()


# ---------------------------------------------------------------- R: runtime fail-closed (defects)

@gate("R1", "Runtime fail-closed", "Reviewer confidence NaN must not auto-apply")
def r1(ctx):
    _, out, events = run_runtime(["candidate", review_json(confidence=float("nan"))])
    return not applied(out), describe(out, events)


@gate("R2", "Runtime fail-closed", "Reviewer confidence outside [0,1] must not auto-apply")
def r2(ctx):
    _, out, events = run_runtime(["candidate", review_json(confidence=7.0)])
    return not applied(out), describe(out, events)


@gate("R3", "Runtime fail-closed", "Malformed reviewer output routes to the manual queue instead of raising out of execute()")
def r3(ctx):
    _, out, events = run_runtime(["candidate", review_json(confidence="0.95")])
    return (not isinstance(out, Exception)) and not out.applied, describe(out, events)


@gate("R4", "Runtime fail-closed", "Truthy non-bool consequence flags ('true', 1) escalate or are rejected, never ignored")
def r4(ctx):
    notes, ok = [], True
    for value in ("true", 1):
        _, out, _ = run_runtime(["candidate", review_json()], consequential_action=value)
        safe = isinstance(out, ValueError) or not applied(out)
        ok = ok and safe
        notes.append(f"{value!r} -> {'held' if safe else 'AUTO-APPLIED'}")
    return ok, "; ".join(notes)


@gate("R5", "Runtime fail-closed", "An adapter failure at generation or at the PATCH stage leaves a terminal ledger event")
def r5(ctx):
    from vinculum.runtime_harness.adapters.mock import MockAdapter

    class FailOn(MockAdapter):
        def __init__(self, responses, fail_call):
            super().__init__(responses)
            self.n, self.fail_call = 0, fail_call

        def complete(self, *args, **kwargs):
            self.n += 1
            if self.n == self.fail_call:
                raise TimeoutError("endpoint timeout")
            return super().complete(*args, **kwargs)

    patch_script = ["candidate", review_json("PATCH", patch_instructions=["fix"]), "PATCHED", review_json()]
    cases = [("generation", FailOn(["candidate", review_json()], 1)), ("patch stage", FailOn(patch_script, 3))]
    ok, notes = True, []
    for label, adapter in cases:
        _, out, events = run_runtime(None, adapter=adapter)
        terminal = [e for e in events if e in ("MANUAL_CERPA_OPENED", "RUNTIME_FAILED", "APPLY_AUTO") or "FAIL" in e]
        good = bool(terminal) and not applied(out)
        ok = ok and good
        notes.append(f"{label}: {type(out).__name__ if isinstance(out, Exception) else out.status}; ledger ends {events[-1]}")
    return ok, "; ".join(notes)


@gate("R7", "Runtime authority evidence", "A human decision names an actor and is recorded in the hash ledger")
def r6(ctx):
    runtime, out, _ = run_runtime(["candidate", review_json()], consequential_action=True)
    before = ledger_events(runtime)
    params = inspect.signature(runtime.manual.decide).parameters
    actor = next((p for p in ("actor", "decided_by", "approver", "operator") if p in params), None)
    kwargs = {"note": "gate probe"}
    if actor:
        kwargs[actor] = "gate-probe-operator"
    runtime.manual.decide(out.manual_case_id, "approve", **kwargs)
    added = ledger_events(runtime)[len(before):]
    return bool(added) and actor is not None, f"actor parameter={actor}; ledger events added by the decision={added or 'none'}"


@gate("R8", "Runtime authority evidence", "Concurrent ledger appends (4 threads x 50) keep a verifiable chain and no writer crashes")
def r7(ctx):
    from vinculum.runtime_harness.core.ledger import HashLedger
    path = pathlib.Path(tempfile.mkdtemp()) / "ledger.jsonl"
    ledger, errors = HashLedger(path), []

    def worker():
        for _ in range(50):
            try:
                ledger.append("EVT", {"t": threading.get_ident()})
            except Exception as exc:  # noqa: BLE001
                errors.append(type(exc).__name__)
                return

    threads = [threading.Thread(target=worker) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    issues = ledger.verify()
    lines = len(path.read_text(encoding="utf-8").splitlines())
    return (not errors and not issues and lines == 200), f"{lines}/200 lines; writer errors={len(errors)}; verify issues={len(issues)}"


@gate("R9", "Runtime authority evidence", "Ledger verification can take an externally retained tip (parity with the Fold journal)")
def r8(ctx):
    from vinculum.runtime_harness.core.ledger import HashLedger
    params = list(inspect.signature(HashLedger.verify).parameters)
    ok = any(k in p for p in params for k in ("tip", "anchor", "expected"))
    return ok, f"HashLedger.verify parameters={params}; EpisodeJournal.verify offers expected_tip"


@gate("R11", "Claims vs enforcement", "An assessment that lists TRUTH_EXPIRED does not also report coherent=True")
def r9(ctx):
    from vinculum.runtime_harness.core.models import CoherenceContext, MemoryRecord, ReasoningFrame, TruthRecord
    from vinculum.runtime_harness.deep_sigma.coherence import TRMEvaluator
    c = CoherenceContext(
        [TruthRecord("ok", "c", "e", "s"), TruthRecord("old", "c", "e", "s", valid_until="2020-01-01T00:00:00Z")],
        ReasoningFrame("i", ["c"]), [MemoryRecord("m", "s")])
    a = TRMEvaluator().evaluate(c)
    contradiction = a.coherent and any(i.startswith("TRUTH_EXPIRED") for i in a.issues)
    return not contradiction, f"coherent={a.coherent}; issues={a.issues}"


@gate("R12", "Claims vs enforcement", "The release holds one stance on JIT compositing (code and shipped limits text agree)")
def r10(ctx):
    from vinculum.runtime_harness.lineage.jit import JITDimensions
    has_composite = hasattr(JITDimensions, "readiness")
    says_none = False
    if ctx.release_dir is not None:
        limits = ctx.release_dir / "docs" / "upstream" / "vinculum_folding_0_1_0" / "SECURITY_AND_LIMITS.md"
        if limits.exists():
            says_none = "no composite score" in limits.read_text(encoding="utf-8").lower()
    detail = (f"runtime lineage JITDimensions.readiness() present={has_composite}"
              + (f" (JITDimensions(1,0,1,0).readiness()={JITDimensions(1, 0, 1, 0).readiness()})" if has_composite else "")
              + f"; shipped Fold limits text says 'JIT has no composite score'={says_none}")
    return not (has_composite and says_none), detail


@gate("R6", "Runtime fail-closed", "A non-finite or out-of-range min_auto_apply_confidence is rejected at construction")
def r11(ctx):
    from vinculum.runtime_harness.adapters.mock import MockAdapter
    from vinculum.runtime_harness.runtime import VinculumRuntime
    tmp = pathlib.Path(tempfile.mkdtemp())
    notes, ok = [], True
    for value in (float("nan"), -1.0):
        try:
            runtime = VinculumRuntime(MockAdapter(["candidate", review_json(confidence=0.01)]),
                                      tmp / "l.jsonl", tmp / "q.jsonl", min_auto_apply_confidence=value)
            out = runtime.execute("prompt", make_context())
            safe = not out.applied
            notes.append(f"{value!r}: accepted; reviewer confidence 0.01 -> {'held' if safe else 'AUTO-APPLIED'}")
        except ValueError:
            safe = True
            notes.append(f"{value!r}: rejected")
        ok = ok and safe
    return ok, "; ".join(notes)


@gate("R10", "Runtime authority evidence", "Ledger verify() reports a torn final line as an issue instead of raising")
def r12(ctx):
    from vinculum.runtime_harness.core.ledger import HashLedger
    path = pathlib.Path(tempfile.mkdtemp()) / "ledger.jsonl"
    ledger = HashLedger(path)
    for i in range(3):
        ledger.append("EVT", {"i": i})
    path.write_text(path.read_text(encoding="utf-8")[:-40], encoding="utf-8")
    try:
        issues = ledger.verify()
    except Exception as exc:  # noqa: BLE001
        return False, f"verify() raised {type(exc).__name__}"
    return bool(issues), f"verify() -> {issues}"


# ---------------------------------------------------------------- P: packaging and shipped documents (defects)

@gate("P1", "Packaging", "The documented [test] extra installs everything the suite needs (PyYAML)")
def p1(ctx):
    reqs = metadata.requires("vinculum-pylib") or []
    test_reqs = [r for r in reqs if re.search(r"extra\s*==\s*['\"]test['\"]", r)]
    return any("yaml" in r.lower() for r in test_reqs), f"[test] extra requires {test_reqs}"


@gate("P2", "Packaging", "The distribution carries a licence or rights notice")
def p2(ctx):
    meta = metadata.metadata("vinculum-pylib")
    value = meta.get("License") or meta.get("License-Expression")
    has_meta = bool(meta.get_all("License-File")) or bool(value and value.strip().upper() != "UNKNOWN")
    has_file = bool(ctx.release_dir and any((ctx.release_dir / n).exists() for n in ("LICENSE", "LICENSE.md", "LICENSE.txt", "NOTICE")))
    return has_meta or has_file, f"licence metadata={has_meta}; licence/notice file at release root={has_file}"


@gate("P3", "Shipped documents", "SECURITY.md is versioned to this release")
def p3(ctx):
    root = need_release(ctx)
    first = (root / "SECURITY.md").read_text(encoding="utf-8").splitlines()[0]
    version = importlib.import_module("vinculum").__version__
    return version in first, f"header {first!r}; package version {version}"


@gate("P4", "Shipped documents", "SECURITY.md addresses the runtime harness (ledger, manual queue, model endpoint)")
def p4(ctx):
    text = (need_release(ctx) / "SECURITY.md").read_text(encoding="utf-8").lower()
    hits = {k: (k in text) for k in ("ledger", "manual", "endpoint", "runtime")}
    return all(hits.values()), f"mentions={hits}"


@gate("P5", "Shipped documents", "Shipped demo outputs were generated by this release")
def p5(ctx):
    demo = need_release(ctx) / "demo_output"
    found = {}
    for p in sorted(demo.glob("*.json")):
        try:
            v = json.loads(p.read_text(encoding="utf-8")).get("engine_version")
        except (ValueError, AttributeError):
            continue
        if v:
            found[p.name] = v
    version = importlib.import_module("vinculum").__version__
    return bool(found) and all(v == version for v in found.values()), f"engine_version in demo outputs={found}; package={version}"


# ---------------------------------------------------------------- D: regression guards (held on 0.8.0)

@gate("D1", "Regression guard", "Pipeline output is byte-identical across hash seeds")
def d1(ctx):
    root = need_release(ctx)
    code = ("import json,hashlib;from vinculum import VinculumPipeline as P;"
            "d=P().run_file('examples/cross_order_pipeline.json').to_dict();"
            "print(hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest())")
    digests = []
    for seed in ("0", "1", "12345"):
        env = {"PYTHONHASHSEED": seed, "PATH": "/usr/bin:/bin"}
        res = subprocess.run([sys.executable, "-c", code], cwd=root, env=env, capture_output=True, text=True, timeout=120)
        digests.append(res.stdout.strip() or f"ERR:{res.stderr.strip()[-60:]}")
    return len(set(digests)) == 1 and not digests[0].startswith("ERR"), f"distinct digests across 3 seeds={len(set(digests))} ({digests[0][:16]})"


@gate("D2", "Regression guard", "Replacing or removing the narrative context cannot change the numeric report")
def d2(ctx):
    root = need_release(ctx)
    base = json.loads((root / "examples" / "cross_order_scenario.json").read_text(encoding="utf-8"))
    _, h0 = evaluate_scenario(base)
    swapped = copy.deepcopy(base)
    swapped["context"] = {"title": "ALT", "origin_path": ["a"], "retreat_path": ["b"], "attribution": "x"}
    removed = copy.deepcopy(base)
    removed.pop("context", None)
    same = (evaluate_scenario(swapped)[1] == h0, evaluate_scenario(removed)[1] == h0)
    return all(same), f"identical report after replace={same[0]}, remove={same[1]}"


@gate("D3", "Regression guard", "Per-pair results are independent of input order (12 shuffles)")
def d3(ctx):
    root = need_release(ctx)
    base = json.loads((root / "examples" / "cross_order_scenario.json").read_text(encoding="utf-8"))
    reference = pair_signature(evaluate_scenario(base)[0])
    same = 0
    for seed in range(12):
        rnd, shuffled = random.Random(seed), copy.deepcopy(base)
        for key in ("pairs", "representations", "groups", "transformations"):
            if isinstance(shuffled.get(key), list):
                rnd.shuffle(shuffled[key])
        same += pair_signature(evaluate_scenario(shuffled)[0]) == reference
    return same == 12, f"{same}/12 shuffles identical"


@gate("D4", "Regression guard", "In-place edit of a ledger record is detected")
def d4(ctx):
    from vinculum.runtime_harness.core.ledger import HashLedger
    path = pathlib.Path(tempfile.mkdtemp()) / "ledger.jsonl"
    ledger = HashLedger(path)
    for i in range(6):
        ledger.append("EVT", {"i": i})
    lines = path.read_text(encoding="utf-8").splitlines()
    record = json.loads(lines[2])
    record["payload"]["i"] = 99
    lines[2] = json.dumps(record)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    issues = ledger.verify()
    return bool(issues), f"verify() -> {issues}"


@gate("D5", "Regression guard", "Declared consequential_action=True escalates to the manual queue")
def d5(ctx):
    _, out, events = run_runtime(["candidate", review_json()], consequential_action=True)
    return (not isinstance(out, Exception)) and not out.applied and bool(out.manual_case_id), describe(out, events)


@gate("D6", "Regression guard", "A failing reviewer call fails closed to the manual queue")
def d6(ctx):
    from vinculum.runtime_harness.adapters.mock import MockAdapter
    _, out, events = run_runtime(None, adapter=MockAdapter(["candidate"]))  # second call raises inside _review
    return (not isinstance(out, Exception)) and not out.applied and bool(out.manual_case_id), describe(out, events)


@gate("D7", "Regression guard", "A tampered Fold bundle fails verification")
def d7(ctx):
    from vinculum_folding import verify_bundle
    from vinculum_folding.model import FoldError
    out = pathlib.Path(tempfile.mkdtemp()) / "bundle"
    subprocess.run([sys.executable, "-m", "vinculum_folding", "demo", "--out", str(out)],
                   check=True, capture_output=True, timeout=120)
    verify_bundle(out)  # pristine bundle must verify
    target = out / "episode.json"
    raw = bytearray(target.read_bytes())
    raw[len(raw) // 2] ^= 0x01
    target.write_bytes(bytes(raw))
    try:
        verify_bundle(out)
    except FoldError as exc:
        return True, f"FoldError: {exc}"
    return False, "tampered bundle verified"


def _journal_worker(path, episode_id, wid, target, queue):
    from datetime import datetime, timezone
    from vinculum_folding import EpisodeJournal
    from vinculum_folding.model import FoldError
    journal = EpisodeJournal.open(path, read_only=False)
    done, refused, started = 0, 0, time.time()
    while done < target and time.time() - started < 120:
        try:
            tip = journal.history(episode_id)[-1]
            journal.append(tip.revise(recorded_at=datetime.now(timezone.utc).isoformat(), title=f"w{wid}-{done}"))
            done += 1
        except FoldError:
            refused += 1
    journal.close()
    queue.put((wid, done, refused))


@gate("D8", "Regression guard", "Fold journal stays consistent under 4 concurrent writer processes (stale revisions refused)")
def d8(ctx):
    import multiprocessing as mp
    from vinculum_folding import EpisodeJournal
    from vinculum_folding.demo import inspection_demo
    path = pathlib.Path(tempfile.mkdtemp()) / "journal.sqlite"
    journal = EpisodeJournal.create(path)
    seed = inspection_demo()
    journal.append(seed)
    journal.close()
    queue = mp.Queue()
    procs = [mp.Process(target=_journal_worker, args=(str(path), seed.episode_id, w, 25, queue)) for w in range(4)]
    for p in procs:
        p.start()
    for p in procs:
        p.join()
    results = [queue.get() for _ in procs]
    reader = EpisodeJournal.open(path, read_only=True)
    history, verdict = reader.history(seed.episode_id), reader.verify(seed.episode_id)
    appended, refused = sum(r[1] for r in results), sum(r[2] for r in results)
    ok = len(history) == 1 + appended == 101 and verdict["internally_consistent"]
    return ok, f"revisions={len(history)}; appended={appended}; stale appends refused and retried={refused}; internally_consistent={verdict['internally_consistent']}"


def _security_probes(release_dir):
    """Hostile-input probes against the core engine and the HTTP facade. Returns [(name, behaved_as_documented)]."""
    import io
    import os
    import zipfile
    from fractions import Fraction
    from vinculum import interval_calculate
    from vinculum.core import NumericRange
    from vinculum.io import LoadLimits, load_source
    from vinculum.utils import read_json

    out = []

    def reject(name, fn):
        try:
            fn()
            out.append((name, False))
        except Exception:  # noqa: BLE001 - any rejection is the expected behaviour
            out.append((name, True))

    def accept(name, fn):
        try:
            fn()
            out.append((name, True))
        except Exception:  # noqa: BLE001
            out.append((name, False))

    rng = lambda lo, hi: NumericRange(Fraction(lo), Fraction(hi))
    reject("interval: __import__ injection", lambda: interval_calculate("__import__('os').system('echo pwned')", {}))
    reject("interval: attribute access", lambda: interval_calculate("x.__class__", {"x": rng(1, 2)}))
    reject("interval: exponent operator", lambda: interval_calculate("9**9**9", {}))
    reject("interval: expression over 2000 chars", lambda: interval_calculate("1+" * 1500 + "1", {}))
    reject("interval: node budget", lambda: interval_calculate("+".join(["1"] * 120), {}))
    reject("interval: denominator spans zero", lambda: interval_calculate("1/x", {"x": rng(-1, 1)}))
    accept("interval: legitimate expression", lambda: interval_calculate("a*b+1", {"a": rng(1, 2), "b": rng(3, 4)}))
    reject("json: NaN literal", lambda: read_json('{"a": NaN}'))
    reject("json: Infinity literal", lambda: read_json('{"a": Infinity}'))
    reject("json: duplicate key", lambda: read_json('{"a": 1, "a": 2}'))
    tmp = pathlib.Path(tempfile.mkdtemp())
    (tmp / "base").mkdir()
    (tmp / "secret.txt").write_text("outside")
    try:
        os.symlink(tmp / "secret.txt", tmp / "base" / "link.txt")
        reject("loader: symlink escape", lambda: load_source(source_id="s", format="txt", path="link.txt", base_dir=tmp / "base", allow_files=True))
    except OSError:
        pass  # symlink creation not permitted on this host
    reject("loader: path traversal", lambda: load_source(source_id="s", format="txt", path="../secret.txt", base_dir=tmp / "base", allow_files=True))
    reject("loader: files without allow_files", lambda: load_source(source_id="s", format="txt", path="x.txt", base_dir=tmp / "base"))
    reject("loader: over the byte limit", lambda: load_source(source_id="s", format="txt", data="x" * 2000, limits=LoadLimits(max_bytes=1000)))
    reject("loader: sha256 mismatch", lambda: load_source(source_id="s", format="txt", data="abc", expected_sha256="0" * 64))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("word/document.xml", b"A" * 60_000_000)
    reject("loader: zip bomb as DOCX", lambda: load_source(source_id="s", format="docx", data=buf.getvalue(), limits=LoadLimits(max_bytes=25_000_000)))
    try:
        import yaml  # noqa: F401
        reject("yaml: alias", lambda: load_source(source_id="s", format="yaml", data="a: &r [1]\nb: *r\n"))
        reject("yaml: python object tag", lambda: load_source(source_id="s", format="yaml", data="!!python/object/apply:os.system [echo evil]"))
    except ImportError:
        pass
    try:
        from fastapi.testclient import TestClient
        from vinculum.api import create_app
    except ImportError:
        return out, "HTTP facade and YAML subsets skipped when their extras are absent"
    good = "x" * 20
    client = TestClient(create_app(token=good))
    job = json.loads((release_dir / "examples" / "bakery_pipeline.json").read_text(encoding="utf-8"))
    auth = {"Authorization": f"Bearer {good}"}
    post = lambda headers=None, **kw: client.post("/v1/evaluate", headers=headers or {}, **kw).status_code
    out.append(("http: no token -> 401", post(json=job) == 401))
    out.append(("http: wrong token -> 401", post({"Authorization": "Bearer nope"}, json=job) == 401))
    out.append(("http: valid token and job -> 200", post(auth, json=job) == 200))
    out.append(("http: wrong content-type -> 415", post({**auth, "Content-Type": "text/plain"}, content=b"{}") == 415))
    out.append(("http: file-path source -> 422", post(auth, json={**job, "sources": [{"id": "s", "path": "/etc/passwd", "format": "txt"}]}) == 422))
    small = TestClient(create_app(token=good, max_body_bytes=1000))
    out.append(("http: oversized body -> 413", small.post("/v1/evaluate", headers={**auth, "Content-Type": "application/json"}, content=b'{"a":"' + b"x" * 5000 + b'"}').status_code == 413))
    for label, kw in (("no token and no demo flag", {}), ("token under 16 chars", {"token": "short"})):
        try:
            create_app(**kw)
            out.append((f"http: create_app accepts {label}", False))
        except ValueError:
            out.append((f"http: create_app rejects {label}", True))
    return out, ""


@gate("D9", "Regression guard", "Core security boundary behaves as SECURITY.md describes (hostile-input probes, HTTP facade)")
def d9(ctx):
    results, note = _security_probes(need_release(ctx))
    failed = [name for name, ok in results if not ok]
    detail = f"{sum(ok for _, ok in results)}/{len(results)} probes behaved as documented" + (f"; FAILED: {failed}" if failed else "") + (f"; {note}" if note else "")
    return not failed, detail


# ---------------------------------------------------------------- H: Boss-decision items (reported, never failing)

@gate("H1", "Boss decision", "Default runtime path applies a passing candidate with no human step (APPLY_AUTO)")
def h1(ctx):
    _, out, events = run_runtime(["candidate", review_json()])
    if "APPLY_AUTO" in events:
        raise Hold(f"auto-apply active: {describe(out, events)}")
    return True, describe(out, events)


@gate("H2", "Boss decision", "A model-authored patch is applied after a second model review (PATCH -> PASS -> APPLY_AUTO)")
def h2(ctx):
    _, out, events = run_runtime(["candidate", review_json("PATCH", patch_instructions=["fix"]), "PATCHED", review_json()])
    if "APPLY_AUTO" in events:
        raise Hold(f"patch applied without a human step: {describe(out, events)}; final={getattr(out, 'final', None)!r}")
    return True, describe(out, events)


@gate("H3", "Boss decision", "The generating model reviews its own output unless auditor_model is set")
def h3(ctx):
    from vinculum.runtime_harness.adapters.mock import MockAdapter

    class Spy(MockAdapter):
        def __init__(self, responses):
            super().__init__(responses)
            self.calls = []

        def complete(self, system, user, *, temperature=0.2, response_format=None, model=None):
            self.calls.append(("review" if response_format else "generate", model or self.model))
            return super().complete(system, user, temperature=temperature, response_format=response_format, model=model)

    spy = Spy(["candidate", review_json()])
    run_runtime(None, adapter=spy)
    models = {m for _, m in spy.calls}
    if len(models) == 1:
        raise Hold(f"same model for generation and review: {spy.calls}")
    return True, f"independent reviewer: {spy.calls}"


@gate("H4", "Boss decision", "Phase I bridge: a detected drift returns APPLIED with no authority record")
def h4(ctx):
    try:
        importlib.import_module("core.cerpa")
    except ImportError:
        raise Skip("deepsigma (Phase I, PyPI 2.1.3) not installed in this environment")
    from vinculum.runtime_harness.deep_sigma.cerpa import CoreCerpaBridge
    claim = dict(id="C-1", text="Gate 7 remains staffed 24/7", domain="ops", source="plan",
                 timestamp="2026-10-04T00:00:00Z", assumptions=["staffing roster current"], authority="J3")
    event = dict(id="E-1", text="Gate 7 unstaffed", domain="ops", source="obs",
                 timestamp="2026-10-04T01:00:00Z", observed_state={"status": "failed"})
    out = CoreCerpaBridge().run(claim, event)
    if str(out.get("status")).endswith("APPLIED"):
        raise Hold(f"bridge returned status={out['status']} with apply_result.success={out['apply_result']['success']}")
    return True, f"status={out.get('status')}"


# ---------------------------------------------------------------- runner

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--release-dir", type=pathlib.Path, help="extracted release directory (for file and example gates)")
    parser.add_argument("--json", type=pathlib.Path, dest="json_path", help="write results as JSON to this path")
    args = parser.parse_args()
    ctx = Context(args.release_dir.resolve() if args.release_dir else None)

    import vinculum
    print(f"VINCULUM pyLib gate probes | python {sys.version.split()[0]} | vinculum {vinculum.__version__}")
    print(f"imported from {pathlib.Path(vinculum.__file__).parent}\n")

    group_order = ["Runtime fail-closed", "Runtime authority evidence", "Claims vs enforcement", "Packaging",
                   "Shipped documents", "Regression guard", "Boss decision"]
    ordered = sorted(GATES, key=lambda g: (group_order.index(g[1]), int(g[0][1:])))
    rows = []
    for gate_id, group, title, fn in ordered:
        try:
            ok, evidence = fn(ctx)
            result = "PASS" if ok else "FAIL"
        except Skip as exc:
            result, evidence = "SKIP", str(exc)
        except Hold as exc:
            result, evidence = "HOLD", str(exc)
        except Exception as exc:  # noqa: BLE001
            result, evidence = "FAIL", f"{type(exc).__name__}: {exc}"
        rows.append((gate_id, group, result, title, evidence))

    current = None
    for gate_id, group, result, title, evidence in rows:
        if group != current:
            print(f"-- {group}")
            current = group
        print(f"  {gate_id:<4}{result:<5} {title}")
        print(f"            {evidence[:230]}")
    tally = {k: sum(1 for r in rows if r[2] == k) for k in ("PASS", "FAIL", "HOLD", "SKIP")}
    print(f"\nSummary: {tally['PASS']} PASS, {tally['FAIL']} FAIL, {tally['HOLD']} HOLD, {tally['SKIP']} SKIP")
    if args.json_path:
        payload = {"python": sys.version.split()[0], "vinculum": vinculum.__version__, "tally": tally,
                   "gates": [{"id": g, "group": grp, "result": res, "title": t, "evidence": ev} for g, grp, res, t, ev in rows]}
        args.json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return 1 if tally["FAIL"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
