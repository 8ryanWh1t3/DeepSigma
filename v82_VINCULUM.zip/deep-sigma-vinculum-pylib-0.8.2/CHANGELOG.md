# Changelog

## 0.8.2 — candidate

Hardening + containment release. 0.8.1 was not separately shipped; its closed change list is incorporated here.

### Authority
- removed all runtime automatic Apply paths;
- added read-only startup approver roster and actor-attributed decisions;
- made approval, Apply, post-Apply observation and lesson/closure distinct states;
- Core CERPA bridge requires a verified HumanApproval.

### Fail-closed runtime
- strict reviewer JSON/types/ranges;
- strict threshold construction;
- non-bool asserted consequence flags escalate;
- generation/PATCH/review failures create terminal failure evidence and a manual case;
- missing reasoning authority is a preflight coherence failure.

### Integrity
- concurrency-safe hash ledger with fsync, retained tips and torn-line reporting;
- manual queue locking and restricted file permissions;
- portable external ledger anchors.

### Semantics
- removed public universal object score families and cross-order weighted mean;
- JIT remains four independent lenses with no readiness composite;
- team/autonomy authority comes only from trusted state, not caller booleans.

### Product boundaries
- PATHFINDER/RESONATOR/COMPOSER explicitly documented as stubs;
- neutral VINCULUM Graph naming replaces Lattice-named command/surface;
- C-UAS example and DoD autonomy profile removed from current wheel.

### Containment
- HTTPS or loopback HTTP model endpoints only;
- bounded prompt/response sizes;
- explicit statement that this is not an OS sandbox.

## 0.8.0 — 2026-10-04
Frozen negative baseline; release held after external gate evaluation.
