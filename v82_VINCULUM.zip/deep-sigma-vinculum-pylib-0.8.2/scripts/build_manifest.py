"""Generate the release hash-list inventory and GNU-style SHA-256 hash list."""
from __future__ import annotations

import hashlib
import json
from datetime import date
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_NAMES = {"MANIFEST.json", "MANIFEST.sha256"}
EXCLUDED_PARTS = {"__pycache__", ".pytest_cache", ".venv", "build"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


files = sorted(
    path for path in ROOT.rglob("*")
    if path.is_file()
    and path.name not in EXCLUDED_NAMES
    and not EXCLUDED_PARTS.intersection(path.relative_to(ROOT).parts)
    and not path.suffix == ".pyc"
)
entries = [
    {
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }
    for path in files
]
manifest = {
    "schema": "deep-sigma.release-hash-list/1",
    "product": "Deep Sigma / VINCULUM pyLib",
    "version": "0.8.2",
    "generated": date(2026, 10, 4).isoformat(),
    "algorithm": "sha256",
    "file_count_excluding_manifest_files": len(entries),
    "files": entries,
}
manifest_path = ROOT / "MANIFEST.json"
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
checksum_entries = entries + [{
    "path": "MANIFEST.json",
    "bytes": manifest_path.stat().st_size,
    "sha256": sha256(manifest_path),
}]
(ROOT / "MANIFEST.sha256").write_text(
    "".join(f"{entry['sha256']}  {entry['path']}\n" for entry in checksum_entries),
    encoding="utf-8",
)
print(f"Wrote {len(entries)} file entries plus MANIFEST.json checksum")
