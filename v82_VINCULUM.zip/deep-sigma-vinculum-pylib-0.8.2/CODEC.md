# Codec contract — v0.8.2

Codec checks identify declared transformation issues such as uncertainty narrowing. They do not replace pair results, infer truth, or grant permission.
