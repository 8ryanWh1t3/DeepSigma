from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Mapping

from .formulas import DerivedVector


class ObjectType(str, Enum):
    CLAIM = "claim"
    EPISODE = "episode"
    CLAUSE = "clause"
    PARAGRAPH = "paragraph"
    DOCUMENT = "document"
    DATASET = "dataset"
    DATA_ROW = "data_row"
    RDF_TRIPLE = "rdf_triple"
    TTL_GRAPH = "ttl_graph"
    POLICY = "policy"
    DECISION = "decision"
    MODEL_OUTPUT = "model_output"
    SENSOR_OBSERVATION = "sensor_observation"
    CORPUS = "corpus"
    MATH = "math"
    GENERIC = "generic"


class ScoreMode(str, Enum):
    AUTO = "auto"
    LANGUAGE = "language"
    MATH = "math"
    TTL = "ttl"
    STRUCTURED = "structured"


class DominantState(str, Enum):
    UNMEASURED = "UNMEASURED"
    PROBABILISTIC_DOMINANT = "PROBABILISTIC_DOMINANT"
    BOUNDARY_TENSION = "BOUNDARY_TENSION"
    DETERMINISTIC_DOMINANT = "DETERMINISTIC_DOMINANT"


@dataclass(frozen=True)
class Signal:
    id: str
    channel: str
    label: str
    weight: float
    count: int
    examples: tuple[str, ...] = ()
    note: str = ""

    @property
    def contribution(self) -> float:
        return self.weight * self.count


@dataclass(frozen=True)
class VinculumObject:
    object_id: str
    object_type: ObjectType
    content: Any = ""
    mode: ScoreMode = ScoreMode.AUTO
    weight: float = 1.0
    metadata: Mapping[str, Any] = field(default_factory=dict)
    children: tuple["VinculumObject", ...] = ()

    def __post_init__(self) -> None:
        if not self.object_id.strip():
            raise ValueError("object_id cannot be empty")
        if self.weight <= 0:
            raise ValueError("weight must be > 0")
        object.__setattr__(self, "children", tuple(self.children))


@dataclass(frozen=True)
class VinculumResult:
    """Per-object channel diagnostics plus pairwise semantic reconciliation.

    v0.8.2 intentionally exposes no universal object score, usable-value score,
    tension index, or Sigma_V composite. The P/D channels and relationship fields
    remain separately inspectable.
    """
    object_id: str
    object_type: ObjectType
    mode: ScoreMode
    direction: str
    probabilistic_pressure: float
    deterministic_strength: float
    coverage: float
    p_norm: float
    d_norm: float
    vinculum_signed: float
    tension_balance: float
    intensity: float
    dominant_state: DominantState
    unresolved_elements: tuple[str, ...] = ()
    drivers_p: tuple[Signal, ...] = ()
    drivers_d: tuple[Signal, ...] = ()
    children: tuple["VinculumResult", ...] = ()
    reconciliation_status: str = "NO_COMPARISON"
    semantic_record_tension: float = 0.0
    comparison_coverage: float = 0.0
    semantic_determinization_strength: float | None = None
    deterministic_defense_strength: float | None = None
    probabilistic_contamination: float | None = None
    raw_deterministic_strength: float | None = None
    defended_deterministic_strength: float | None = None
    reconciliation: Mapping[str, Any] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_vector(
        cls, *, obj: VinculumObject, mode: ScoreMode, direction: str,
        P: float, D: float, coverage: float, vector: DerivedVector,
        unresolved: tuple[str, ...] = (), drivers_p: tuple[Signal, ...] = (),
        drivers_d: tuple[Signal, ...] = (), children: tuple["VinculumResult", ...] = (),
        metadata: Mapping[str, Any] | None = None,
        reconciliation_status: str = "NO_COMPARISON", semantic_record_tension: float = 0.0,
        comparison_coverage: float = 0.0, reconciliation: Mapping[str, Any] | None = None,
        semantic_determinization_strength: float | None = None,
        deterministic_defense_strength: float | None = None,
        probabilistic_contamination: float | None = None,
        raw_deterministic_strength: float | None = None,
        defended_deterministic_strength: float | None = None,
        boundary_low: float = 40.0, boundary_high: float = 60.0,
        minimum_coverage: float = 0.15,
    ) -> "VinculumResult":
        # Historical 40/60 boundaries map to signed relation -0.2/+0.2 without
        # recreating the removed 0..100 composite score.
        low_v = (float(boundary_low) / 50.0) - 1.0
        high_v = (float(boundary_high) / 50.0) - 1.0
        if coverage < minimum_coverage:
            state = DominantState.UNMEASURED
        elif vector.signed_relation < low_v:
            state = DominantState.PROBABILISTIC_DOMINANT
        elif vector.signed_relation > high_v:
            state = DominantState.DETERMINISTIC_DOMINANT
        else:
            state = DominantState.BOUNDARY_TENSION
        clamp=lambda x: max(0.0,min(1.0,float(x)))
        return cls(
            object_id=obj.object_id, object_type=obj.object_type, mode=mode, direction=direction,
            probabilistic_pressure=P, deterministic_strength=D, coverage=coverage,
            p_norm=vector.p_norm, d_norm=vector.d_norm, vinculum_signed=vector.signed_relation,
            tension_balance=vector.balance, intensity=vector.intensity, dominant_state=state,
            unresolved_elements=tuple(unresolved), drivers_p=tuple(drivers_p), drivers_d=tuple(drivers_d),
            children=tuple(children), reconciliation_status=reconciliation_status,
            semantic_record_tension=clamp(semantic_record_tension), comparison_coverage=clamp(comparison_coverage),
            semantic_determinization_strength=(None if semantic_determinization_strength is None else clamp(semantic_determinization_strength)),
            deterministic_defense_strength=(None if deterministic_defense_strength is None else clamp(deterministic_defense_strength)),
            probabilistic_contamination=(None if probabilistic_contamination is None else clamp(probabilistic_contamination)),
            raw_deterministic_strength=(None if raw_deterministic_strength is None else clamp(raw_deterministic_strength)),
            defended_deterministic_strength=(None if defended_deterministic_strength is None else clamp(defended_deterministic_strength)),
            reconciliation=dict(reconciliation or {}), metadata=dict(metadata or {}),
        )

    @property
    def collision_strength(self) -> float:
        return self.semantic_record_tension

    @property
    def collision_coverage(self) -> float:
        return self.comparison_coverage

    @property
    def collision_status(self) -> str:
        return self.reconciliation_status

    @property
    def primary_collision(self) -> Mapping[str, Any] | None:
        value=self.reconciliation.get("primary_comparison")
        return value if isinstance(value,Mapping) else None

    def to_dict(self, *, include_children: bool = True) -> dict[str, Any]:
        def signal_dict(s: Signal) -> dict[str, Any]:
            return {"id":s.id,"channel":s.channel,"label":s.label,"weight":s.weight,"count":s.count,
                    "contribution":s.contribution,"examples":list(s.examples),"note":s.note}
        out={
            "object_id":self.object_id,"object_type":self.object_type.value,"mode":self.mode.value,"direction":self.direction,
            "channels":{
                "probabilistic_pressure":self.probabilistic_pressure,
                "deterministic_strength":self.deterministic_strength,
                "coverage":self.coverage,
                "p_norm":self.p_norm,"d_norm":self.d_norm,
                "signed_relation":self.vinculum_signed,
                "balance":self.tension_balance,
                "intensity":self.intensity,
            },
            "probabilistic_pressure":self.probabilistic_pressure,
            "deterministic_strength":self.deterministic_strength,
            "coverage":self.coverage,
            "p_norm":self.p_norm,"d_norm":self.d_norm,"vinculum_signed":self.vinculum_signed,
            "tension_balance":self.tension_balance,"intensity":self.intensity,
            "dominant_state":self.dominant_state.value,
            "unresolved_elements":list(self.unresolved_elements),
            "reconciliation_status":self.reconciliation_status,
            "semantic_record_tension":self.semantic_record_tension,
            "comparison_coverage":self.comparison_coverage,
            "second_order":{
                "S_L_semantic_determinization_strength":self.semantic_determinization_strength,
                "R_D_deterministic_defense_strength":self.deterministic_defense_strength,
                "U_D_probabilistic_contamination":self.probabilistic_contamination,
                "D_raw_first_order_determinism":self.raw_deterministic_strength,
                "D_effective_defended_determinism":self.defended_deterministic_strength,
            },
            "collision_model":{
                "status":self.collision_status,"collision_strength":self.collision_strength,
                "collision_coverage":self.collision_coverage,
                "primary_collision":self.primary_collision,
            },
            "semantic_reconciliation":dict(self.reconciliation),
            "drivers_P":[signal_dict(s) for s in self.drivers_p],
            "drivers_D":[signal_dict(s) for s in self.drivers_d],
            "metadata":dict(self.metadata),
            "boundary":"channel diagnostics and pairwise relations; not truth, risk, readiness, or permission",
        }
        if include_children: out["children"]=[c.to_dict(include_children=True) for c in self.children]
        return out
