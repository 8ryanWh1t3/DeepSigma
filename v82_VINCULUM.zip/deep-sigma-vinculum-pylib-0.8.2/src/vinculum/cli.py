from __future__ import annotations
import argparse,json
from pathlib import Path
from .engine import VinculumEngine
from .ingest import ingest_file,ingest_mapping,ingest_text
from .models import ObjectType,ScoreMode


def _type(v:str)->ObjectType:return ObjectType(v)
def _mode(v:str)->ScoreMode:return ScoreMode(v)


def main(argv:list[str]|None=None)->int:
    parser=argparse.ArgumentParser(prog="vinculum",description="VINCULUM pyLib v0.8.2 — bounded channel inspection and semantic reconciliation")
    sub=parser.add_subparsers(dest="command",required=True)
    inspect_cmd=sub.add_parser("inspect",help="Inspect text or a file without emitting a universal score")
    inspect_cmd.add_argument("input"); inspect_cmd.add_argument("--type",dest="object_type",type=_type,choices=list(ObjectType),default=None)
    inspect_cmd.add_argument("--mode",type=_mode,choices=list(ScoreMode),default=ScoreMode.AUTO); inspect_cmd.add_argument("--id",dest="object_id")
    inspect_cmd.add_argument("--pretty",action="store_true"); inspect_cmd.add_argument("--summary",action="store_true")
    js=sub.add_parser("inspect-json",help="Inspect an episode/dataset/corpus JSON file"); js.add_argument("path",type=Path)
    js.add_argument("--type",dest="object_type",type=_type,choices=list(ObjectType),default=ObjectType.EPISODE); js.add_argument("--pretty",action="store_true"); js.add_argument("--summary",action="store_true")
    # Deprecated aliases keep old scripts functioning without reintroducing score fields.
    for name,target in (("score","inspect"),("score-json","inspect-json")):
        ap=sub.add_parser(name,help=argparse.SUPPRESS)
        if target=="inspect":
            ap.add_argument("input"); ap.add_argument("--type",dest="object_type",type=_type,choices=list(ObjectType),default=None); ap.add_argument("--mode",type=_mode,choices=list(ScoreMode),default=ScoreMode.AUTO); ap.add_argument("--id",dest="object_id"); ap.add_argument("--pretty",action="store_true"); ap.add_argument("--summary",action="store_true")
        else:
            ap.add_argument("path",type=Path); ap.add_argument("--type",dest="object_type",type=_type,choices=list(ObjectType),default=ObjectType.EPISODE); ap.add_argument("--pretty",action="store_true"); ap.add_argument("--summary",action="store_true")
    args=parser.parse_args(argv); engine=VinculumEngine()
    if args.command in {"inspect","score"}:
        p=Path(args.input)
        try:is_file=p.exists() and p.is_file()
        except OSError:is_file=False
        obj=ingest_file(p,object_type=args.object_type,mode=args.mode) if is_file else ingest_text(args.input,object_type=args.object_type or ObjectType.CLAIM,object_id=args.object_id,mode=args.mode)
        result=engine.inspect(obj)
    else:
        data=json.loads(args.path.read_text(encoding="utf-8")); result=engine.inspect(ingest_mapping(data,object_type=args.object_type,object_id=args.path.name))
    print(json.dumps(result.to_dict(include_children=not args.summary),indent=2 if args.pretty else None,sort_keys=True,allow_nan=False)); return 0

if __name__=="__main__": raise SystemExit(main())
