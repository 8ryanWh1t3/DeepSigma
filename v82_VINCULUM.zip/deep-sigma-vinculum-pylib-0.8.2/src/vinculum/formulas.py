from __future__ import annotations
from dataclasses import dataclass


def clamp01(value: float) -> float:
    return max(0.0,min(1.0,float(value)))


@dataclass(frozen=True)
class ChannelRelation:
    """Relationship diagnostics for P/D channels; not a score, truth, or permission."""
    p_norm: float
    d_norm: float
    signed_relation: float
    balance: float
    intensity: float


def derive_vector(P: float,D: float,coverage: float) -> ChannelRelation:
    """Backward-compatible function name returning non-composite channel diagnostics.

    P and D remain independent declared/derived pressures. The returned signed relation
    is directional geometry only. Coverage is intentionally not folded into one number.
    """
    P=clamp01(P); D=clamp01(D); _=clamp01(coverage)
    total=P+D
    if total<=1e-15: p=d=0.5
    else: p=P/total; d=D/total
    v=max(-1.0,min(1.0,d-p))
    return ChannelRelation(p,d,v,1.0-abs(v),(P+D)/2.0)

# Historical import name retained without historical composite fields.
DerivedVector=ChannelRelation
