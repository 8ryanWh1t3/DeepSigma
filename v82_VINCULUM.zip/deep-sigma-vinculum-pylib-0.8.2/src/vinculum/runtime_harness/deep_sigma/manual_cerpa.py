from __future__ import annotations
import json, os, uuid
from dataclasses import asdict
from pathlib import Path
from typing import List, Literal, Optional
from ..core.models import ManualCerpaCase, ReviewResult, utc_now
from ..core.authority import ApproverRoster
from ..core.ledger import HashLedger
from ..core.locking import exclusive_lock


class ManualCerpaQueue:
    """Human-speed authority queue.

    Approval is attributable but not identity-authenticating: the host must map its
    authenticated principal to an actor_id present in the immutable startup roster.
    """
    def __init__(self, path: str | Path, *, roster: ApproverRoster | None = None, ledger: HashLedger | None = None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.roster = roster
        self.ledger = ledger
        if not self.path.exists():
            fd = os.open(self.path, os.O_CREAT | os.O_WRONLY, 0o600); os.close(fd)
        try: os.chmod(self.path, 0o600)
        except OSError: pass

    def _append_unlocked(self, c: ManualCerpaCase):
        fd = os.open(self.path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
        try:
            os.write(fd, (json.dumps(asdict(c), ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n").encode())
            os.fsync(fd)
        finally:
            os.close(fd)

    def _current_unlocked(self) -> List[ManualCerpaCase]:
        latest = {}
        if not self.path.exists(): return []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip(): continue
            raw=json.loads(line); raw["review"]=ReviewResult(**raw["review"])
            c=ManualCerpaCase(**raw); latest[c.case_id]=c
        return sorted(latest.values(), key=lambda c: c.created_at)

    def current(self) -> List[ManualCerpaCase]:
        with exclusive_lock(self.path):
            return self._current_unlocked()

    def open(self, trigger: str, prompt: str, candidate: str, review: ReviewResult) -> ManualCerpaCase:
        c=ManualCerpaCase(f"MC-{uuid.uuid4().hex[:10].upper()}", utc_now(), "OPEN", trigger, prompt, candidate, review)
        with exclusive_lock(self.path): self._append_unlocked(c)
        return c

    def _get_unlocked(self, case_id: str) -> ManualCerpaCase:
        for c in self._current_unlocked():
            if c.case_id == case_id: return c
        raise KeyError(case_id)

    def get(self, case_id: str) -> ManualCerpaCase:
        with exclusive_lock(self.path): return self._get_unlocked(case_id)

    def _require_actor(self, actor: str, authority: str | None = None):
        if not actor or not actor.strip(): raise ValueError("actor is required")
        if self.roster is None: raise ValueError("AUTHORITY_MISSING: no startup approver roster")
        return self.roster.require(actor, authority)

    def decide(self, case_id: str, decision: Literal["approve","reject","patch"], *, actor: str, authority: str | None = None, note: str="", final_response: Optional[str]=None) -> ManualCerpaCase:
        approver=self._require_actor(actor, authority)
        with exclusive_lock(self.path):
            c=self._get_unlocked(case_id)
            if c.state not in ("OPEN","UNDER_REVIEW","PATCH_REQUESTED"): raise ValueError("case already decided")
            c.state={"approve":"APPROVED","reject":"REJECTED","patch":"PATCH_REQUESTED"}[decision]
            c.decision=decision; c.decided_by=actor; c.operator_note=note; c.decided_at=utc_now()
            c.final_response=(final_response or c.candidate) if decision=="approve" else final_response if decision=="patch" else None
            self._append_unlocked(c)
        if self.ledger:
            self.ledger.append("MANUAL_CERPA_DECIDED",{"case_id":case_id,"decision":decision,"actor":actor,"authorities":list(approver.authorities),"roster_hash":self.roster.source_hash})
        return c

    def record_applied(self, case_id: str, *, actor: str, authority: str | None = None, final_response: Optional[str]=None) -> ManualCerpaCase:
        self._require_actor(actor, authority)
        with exclusive_lock(self.path):
            c=self._get_unlocked(case_id)
            if c.state != "APPROVED": raise ValueError("case must be APPROVED before APPLIED")
            c.state="APPLIED"; c.applied_by=actor; c.applied_at=utc_now()
            if final_response is not None: c.final_response=final_response
            self._append_unlocked(c)
        if self.ledger: self.ledger.append("MANUAL_CERPA_APPLIED",{"case_id":case_id,"actor":actor})
        return c

    def close_after_observation(self, case_id: str, *, actor: str, observed_outcome: str, expected_state_met: bool, lesson_record_id: str, authority: str | None = None) -> ManualCerpaCase:
        self._require_actor(actor, authority)
        if not observed_outcome.strip(): raise ValueError("observed_outcome is required")
        if not lesson_record_id.strip(): raise ValueError("lesson_record_id is required")
        with exclusive_lock(self.path):
            c=self._get_unlocked(case_id)
            if c.state != "APPLIED": raise ValueError("case must be APPLIED before post-apply closure")
            c.post_apply_checked_by=actor; c.post_apply_checked_at=utc_now(); c.observed_outcome=observed_outcome
            c.expected_state_met=bool(expected_state_met); c.lesson_record_id=lesson_record_id; c.state="CLOSED"; c.closed_at=utc_now()
            self._append_unlocked(c)
        if self.ledger:
            self.ledger.append("POST_APPLY_CHECK",{"case_id":case_id,"actor":actor,"expected_state_met":bool(expected_state_met),"observed_outcome":observed_outcome})
            self.ledger.append("LESSON_RECORDED",{"case_id":case_id,"lesson_record_id":lesson_record_id})
            self.ledger.append("CERPA_CASE_CLOSED",{"case_id":case_id})
        return c
