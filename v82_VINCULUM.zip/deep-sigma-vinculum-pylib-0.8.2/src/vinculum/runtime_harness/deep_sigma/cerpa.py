"""VINCULUM-to-Deep-Sigma CERPA bridge.

The canonical CERPA implementation lives in Deep Sigma Core when separately installed.
This bridge refuses to call APPLY-bearing Phase I code without verified human approval.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict
from ..core.authority import HumanApproval

CERPA_PHASES=("CLAIM","EVENT","REVIEW","PATCH","APPLY","POST_APPLY_CHECK","LESSON")

@dataclass
class CoreCerpaBridgeStatus:
    available: bool
    detail: str

class CoreCerpaBridge:
    def status(self)->CoreCerpaBridgeStatus:
        try:
            import core.cerpa  # type: ignore
            return CoreCerpaBridgeStatus(True,"Deep Sigma Core CERPA available")
        except Exception as exc:
            return CoreCerpaBridgeStatus(False,f"Deep Sigma Core CERPA unavailable: {type(exc).__name__}")

    def run(self,claim:Dict[str,Any],event:Dict[str,Any],*,approval:HumanApproval|None=None)->Dict[str,Any]:
        if approval is None: raise ValueError("AUTHORITY_MISSING")
        from core.cerpa.engine import run_cerpa_cycle  # type: ignore
        from core.cerpa.models import Claim,Event  # type: ignore
        cycle=run_cerpa_cycle(Claim(**claim),Event(**event))
        out=cycle.to_dict()
        out["vinculum_authority"]={"actor_id":approval.actor_id,"authority":approval.authority,"roster_hash":approval.roster_hash}
        out["closure_required"]="POST_APPLY_CHECK_AND_LESSON"
        return out
