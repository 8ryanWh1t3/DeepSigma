from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Any
from ..core.authority import ApproverRoster

@dataclass
class AgentState:
    agent_id: str
    role: str
    intent: str
    authority: List[str]
    truth_state: Dict[str,Any]=field(default_factory=dict)
    reasoning_state: Dict[str,Any]=field(default_factory=dict)
    memory_state: Dict[str,Any]=field(default_factory=dict)
    mission_state: Dict[str,Any]=field(default_factory=dict)
    issues: List[str]=field(default_factory=list)

@dataclass
class TeamCoherence:
    agent_count: int
    intent_mismatches: List[str]
    authority_conflicts: List[str]
    issue_count: int
    mission_coherent: bool


def rollup(agents:List[AgentState],commander_intent:str,*,trusted_authority:ApproverRoster|None=None)->TeamCoherence:
    if not agents: return TeamCoherence(0,[],[],0,False)
    mismatches=[a.agent_id for a in agents if a.intent and commander_intent and a.intent!=commander_intent]
    authority=[]
    for a in agents:
        if not a.authority or trusted_authority is None:
            authority.append(a.agent_id); continue
        try:
            # Agent IDs are treated as references only when present in trusted state.
            actor=trusted_authority.actor(a.agent_id)
            if any(x not in actor.authorities for x in a.authority): authority.append(a.agent_id)
        except Exception:
            authority.append(a.agent_id)
    issue_count=sum(len(a.issues) for a in agents)
    mission=not mismatches and not authority and issue_count==0
    return TeamCoherence(len(agents),mismatches,authority,issue_count,mission)
