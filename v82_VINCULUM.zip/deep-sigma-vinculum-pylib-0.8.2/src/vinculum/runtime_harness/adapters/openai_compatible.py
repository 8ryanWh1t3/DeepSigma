from __future__ import annotations
import json,time,urllib.request
from typing import Dict,Any,List,Optional
from .base import ModelResponse
from ..containment import ContainmentPolicy, validate_model_url

class OpenAICompatibleAdapter:
    def __init__(self,model:str,base_url:str,api_key:str="local",*,containment:ContainmentPolicy=ContainmentPolicy()):
        self.model=model; self.base_url=validate_model_url(base_url,containment); self.api_key=api_key; self.containment=containment

    def _request(self,path:str,payload:Optional[Dict[str,Any]]=None)->Dict[str,Any]:
        data=None if payload is None else json.dumps(payload,allow_nan=False).encode()
        req=urllib.request.Request(self.base_url+path,data=data,headers={"Content-Type":"application/json","Authorization":f"Bearer {self.api_key}"})
        with urllib.request.urlopen(req,timeout=120) as resp: return json.loads(resp.read().decode())

    def list_models(self)->List[str]:
        raw=self._request("/models"); return [x["id"] for x in raw.get("data",[])]

    def complete(self,system:str,user:str,*,temperature:float=0.2,response_format:Optional[Dict[str,Any]]=None,model:Optional[str]=None)->ModelResponse:
        if len(system)+len(user)>self.containment.max_prompt_chars: raise ValueError("prompt exceeds containment limit")
        payload={"model":model or self.model,"messages":[{"role":"system","content":system},{"role":"user","content":user}],"temperature":temperature}
        if response_format is not None: payload["response_format"]=response_format
        t=time.perf_counter(); raw=self._request("/chat/completions",payload); ms=(time.perf_counter()-t)*1000
        content=raw["choices"][0]["message"].get("content","") or ""
        if len(content)>self.containment.max_response_chars: raise ValueError("model response exceeds containment limit")
        return ModelResponse(content,payload["model"],ms,raw)
