"""Nano Sigma integration contract: Trinity + VINCULUM Graph + SQLite.

The graph name is product-neutral and does not imply Anduril Lattice integration.
Trinity calls the graph port; it never reaches SQLite directly.
"""
from __future__ import annotations
from typing import Protocol,Dict,Any,List

class VinculumGraphPort(Protocol):
    def get(self,object_id:str)->Dict[str,Any]: ...
    def neighbors(self,object_id:str)->List[Dict[str,Any]]: ...
    def register_artifact(self,artifact:Dict[str,Any])->str: ...
    def reconcile(self,bundle:Dict[str,Any])->Dict[str,Any]: ...

NANO_SIGMA_FORMULA="Trinity + VINCULUM Graph + SQLite"
