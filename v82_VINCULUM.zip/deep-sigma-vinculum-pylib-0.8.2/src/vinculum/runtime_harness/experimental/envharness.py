"""envHarness — controlled test selector for semantic residuals.

Ranks staff-supplied discriminating tests; it does not authorize or apply model changes.
A test is never eligible from a caller-supplied boolean alone.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from ..core.authority import ApproverRoster

@dataclass
class Hypothesis:
    hypothesis_id:str
    description:str
    prior:float

@dataclass
class CandidateTest:
    test_id:str
    description:str
    expected_information_gain:float
    falsification_value:float
    cost:float=0.0
    risk:float=0.0
    time:float=0.0
    mode:str="analysis"
    authority_actor:Optional[str]=None
    authority_required:Optional[str]=None

@dataclass
class SemanticResidual:
    residual_id:str
    expected:str
    observed:str
    hypotheses:List[Hypothesis]
    provenance:List[str]=field(default_factory=list)

@dataclass
class RankedTest:
    test:CandidateTest
    rank_key:tuple
    eligible:bool
    reason:str


def rank_tests(residual:SemanticResidual,tests:List[CandidateTest],*,max_cost:float,max_risk:float,max_time:float,permitted_modes:Optional[List[str]]=None,trusted_authority:ApproverRoster|None=None)->List[RankedTest]:
    permitted_modes=permitted_modes or ["analysis"]
    out=[]
    for t in tests:
        authority_ok=False
        if trusted_authority is not None and t.authority_actor and t.authority_required:
            try:
                trusted_authority.require(t.authority_actor,t.authority_required); authority_ok=True
            except Exception: authority_ok=False
        gates=(t.cost<=max_cost,t.risk<=max_risk,t.time<=max_time,t.mode in permitted_modes,authority_ok)
        eligible=all(gates)
        # No weighted composite. Lexicographic ordering keeps declared priorities visible.
        rank_key=(-float(t.expected_information_gain),-float(t.falsification_value),float(t.risk),float(t.cost),float(t.time),t.test_id)
        reason="eligible" if eligible else "AUTHORITY_MISSING/risk/cost/time/mode gate"
        out.append(RankedTest(t,rank_key,eligible,reason))
    return sorted(out,key=lambda x:(not x.eligible,x.rank_key))
