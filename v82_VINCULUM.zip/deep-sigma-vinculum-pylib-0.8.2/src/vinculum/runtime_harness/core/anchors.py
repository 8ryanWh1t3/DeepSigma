"""External ledger anchoring helpers.

The anchor is a portable checkpoint that another trusted system may retain or sign.
This module does not claim the local anchor file is itself immutable.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
import hashlib, json
from pathlib import Path
from .ledger import HashLedger
from .models import utc_now


@dataclass(frozen=True)
class LedgerAnchor:
    schema: str
    ledger_id: str
    length: int
    tip_hash: str
    created_at: str

    def digest(self) -> str:
        body = json.dumps(asdict(self), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
        return hashlib.sha256(body).hexdigest()


def create_anchor(ledger: HashLedger, *, ledger_id: str) -> LedgerAnchor:
    length, tip_hash = ledger.tip()
    return LedgerAnchor("vinculum.ledger_anchor/1", ledger_id, length, tip_hash, utc_now())


def write_anchor(anchor: LedgerAnchor, path: str | Path) -> None:
    Path(path).write_text(json.dumps({**asdict(anchor), "anchor_sha256": anchor.digest()}, indent=2) + "\n", encoding="utf-8")


def verify_anchor(ledger: HashLedger, anchor: LedgerAnchor) -> list[str]:
    return ledger.verify(expected_tip=(anchor.length, anchor.tip_hash), expected_length=anchor.length)
