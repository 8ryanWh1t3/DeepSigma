from __future__ import annotations
import hashlib, json, os
from pathlib import Path
from typing import Any, Dict, List, Tuple
from .models import utc_now
from .locking import exclusive_lock


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


class LedgerCorruptError(ValueError):
    pass


class HashLedger:
    """Hash-chained JSONL ledger.

    Tamper-evident only. An externally retained tip/length is required to detect a
    validly re-chained truncation. v0.8.2 exposes `tip()` and anchor helpers for that.
    """
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            fd = os.open(self.path, os.O_CREAT | os.O_WRONLY, 0o600)
            os.close(fd)
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    def _records_unlocked(self):
        records = []
        if not self.path.exists():
            return records
        with self.path.open("rb") as f:
            for idx, raw in enumerate(f, 1):
                if not raw.strip():
                    continue
                try:
                    records.append((idx, json.loads(raw.decode("utf-8"))))
                except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                    raise LedgerCorruptError(f"line {idx}: malformed/torn JSON record") from exc
        return records

    def _tip_unlocked(self) -> Tuple[int, str]:
        records = self._records_unlocked()
        if not records:
            return (0, "GENESIS")
        return (len(records), records[-1][1].get("hash", ""))

    def tip(self) -> Tuple[int, str]:
        with exclusive_lock(self.path):
            return self._tip_unlocked()

    def append(self, event_type: str, payload: Dict[str, Any]) -> str:
        with exclusive_lock(self.path):
            length, prev_hash = self._tip_unlocked()
            if length and not prev_hash:
                raise LedgerCorruptError("ledger tail missing hash")
            event = {"ts": utc_now(), "event": event_type, "prev_hash": prev_hash, "payload": payload}
            event["hash"] = hashlib.sha256(canonical_json(event).encode()).hexdigest()
            data = (json.dumps(event, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n").encode("utf-8")
            fd = os.open(self.path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
            try:
                os.write(fd, data)
                os.fsync(fd)
            finally:
                os.close(fd)
            return event["hash"]

    def verify(self, expected_tip: str | tuple[int, str] | None = None, expected_length: int | None = None) -> List[str]:
        issues: List[str] = []
        prev = "GENESIS"
        count = 0
        with exclusive_lock(self.path):
            if not self.path.exists():
                if expected_length not in (None, 0):
                    issues.append("ledger missing; expected records")
                return issues
            with self.path.open("rb") as f:
                for idx, raw in enumerate(f, 1):
                    if not raw.strip():
                        continue
                    count += 1
                    try:
                        record = json.loads(raw.decode("utf-8"))
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        issues.append(f"line {idx}: malformed/torn JSON record")
                        break
                    if not isinstance(record, dict) or "hash" not in record:
                        issues.append(f"line {idx}: invalid ledger record")
                        break
                    h = record["hash"]
                    body = {k: v for k, v in record.items() if k != "hash"}
                    if body.get("prev_hash") != prev:
                        issues.append(f"line {idx}: prev_hash mismatch")
                    try:
                        expected = hashlib.sha256(canonical_json(body).encode()).hexdigest()
                    except (TypeError, ValueError):
                        issues.append(f"line {idx}: non-canonical payload")
                        break
                    if h != expected:
                        issues.append(f"line {idx}: hash mismatch")
                    prev = h
            if expected_length is not None and count != expected_length:
                issues.append(f"length mismatch: expected {expected_length}, got {count}")
            if expected_tip is not None:
                if isinstance(expected_tip, tuple):
                    exp_len, exp_hash = expected_tip
                    if count != exp_len:
                        issues.append(f"anchor length mismatch: expected {exp_len}, got {count}")
                else:
                    exp_hash = expected_tip
                if prev != exp_hash:
                    issues.append("tip hash mismatch")
        return issues
