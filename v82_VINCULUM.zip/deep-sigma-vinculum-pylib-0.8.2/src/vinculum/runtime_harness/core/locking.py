"""Small cross-platform advisory file lock used by runtime JSONL stores.

This is process coordination, not an authentication or trust primitive.
"""
from __future__ import annotations

from contextlib import contextmanager
import os
from pathlib import Path
import time


@contextmanager
def exclusive_lock(target: str | Path, *, timeout: float = 30.0):
    lock_path = Path(str(target) + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    # A single byte gives msvcrt.locking a stable range on Windows.
    if not lock_path.exists():
        fd = os.open(lock_path, os.O_CREAT | os.O_WRONLY, 0o600)
        try:
            os.write(fd, b"0")
            os.fsync(fd)
        finally:
            os.close(fd)
    try:
        os.chmod(lock_path, 0o600)
    except OSError:
        pass
    f = lock_path.open("r+b", buffering=0)
    start = time.monotonic()
    try:
        if os.name == "nt":
            import msvcrt
            while True:
                try:
                    f.seek(0)
                    msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    if time.monotonic() - start >= timeout:
                        raise TimeoutError(f"lock timeout: {lock_path}")
                    time.sleep(0.01)
        else:
            import fcntl
            while True:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() - start >= timeout:
                        raise TimeoutError(f"lock timeout: {lock_path}")
                    time.sleep(0.01)
        yield
    finally:
        try:
            if os.name == "nt":
                import msvcrt
                f.seek(0)
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        finally:
            f.close()
