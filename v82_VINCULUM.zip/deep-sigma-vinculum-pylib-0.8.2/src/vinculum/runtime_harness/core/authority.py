"""Immutable runtime authority snapshot.

The library verifies that an actor/authority reference exists in a startup snapshot.
It does not authenticate a person's real-world identity. Host IAM remains responsible
for binding an authenticated principal to the actor ID supplied here.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from types import MappingProxyType
from typing import Iterable, Mapping


class AuthorityMissing(ValueError):
    pass


@dataclass(frozen=True)
class Approver:
    actor_id: str
    authorities: tuple[str, ...]
    active: bool = True

    def __post_init__(self):
        if not self.actor_id or not self.actor_id.strip():
            raise ValueError("actor_id cannot be empty")
        object.__setattr__(self, "authorities", tuple(self.authorities))
        if not self.authorities:
            raise ValueError("approver requires at least one authority")


class ApproverRoster:
    """Read-only startup roster. No mutation API is provided."""
    def __init__(self, approvers: Iterable[Approver], *, source_hash: str = "inline"):
        data = {a.actor_id: a for a in approvers}
        if len(data) == 0:
            raise ValueError("approver roster cannot be empty")
        self._approvers = MappingProxyType(data)
        self.source_hash = source_hash

    @classmethod
    def from_file(cls, path: str | Path) -> "ApproverRoster":
        path = Path(path)
        raw_bytes = path.read_bytes()
        raw = json.loads(raw_bytes.decode("utf-8"), parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f"invalid JSON constant {x}")))
        if not isinstance(raw, dict) or set(raw) - {"schema", "approvers"} or raw.get("schema") != "vinculum.approver_roster/1":
            raise ValueError("invalid approver roster schema")
        approvers = []
        for item in raw.get("approvers", []):
            if not isinstance(item, dict) or set(item) - {"actor_id", "authorities", "active"}:
                raise ValueError("invalid approver roster entry")
            approvers.append(Approver(item["actor_id"], tuple(item.get("authorities", ())), bool(item.get("active", True))))
        return cls(approvers, source_hash=hashlib.sha256(raw_bytes).hexdigest())

    def actor(self, actor_id: str) -> Approver:
        try:
            a = self._approvers[actor_id]
        except KeyError as exc:
            raise AuthorityMissing("AUTHORITY_MISSING") from exc
        if not a.active:
            raise AuthorityMissing("AUTHORITY_INACTIVE")
        return a

    def require(self, actor_id: str, authority: str | None = None) -> Approver:
        a = self.actor(actor_id)
        if authority and authority not in a.authorities:
            raise AuthorityMissing("AUTHORITY_MISSING")
        return a

    def can_write(self) -> bool:
        return False

    def snapshot(self) -> Mapping[str, Approver]:
        return self._approvers


@dataclass(frozen=True)
class HumanApproval:
    actor_id: str
    authority: str
    roster_hash: str
    note: str = ""

    @classmethod
    def verify(cls, roster: ApproverRoster, actor_id: str, authority: str, note: str = "") -> "HumanApproval":
        roster.require(actor_id, authority)
        return cls(actor_id, authority, roster.source_hash, note)
