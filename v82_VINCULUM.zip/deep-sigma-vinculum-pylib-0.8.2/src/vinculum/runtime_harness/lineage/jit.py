"""Journey Into Truth — four independent verification lenses.

The lenses are not composited into a readiness/truth score. They remain inspectable
independent dimensions so a strong value in one lens cannot compensate for a failure
in another.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import math
from typing import Dict, List


@dataclass(frozen=True)
class JITDimensions:
    legacy_of_precision: float
    density_of_exposure: float
    matrix_of_awareness: float
    ontological_grade: float

    def __post_init__(self):
        for name, value in self.as_dict().items():
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(float(value)) or not 0 <= float(value) <= 1:
                raise ValueError(f"{name} must be finite and in [0,1]")

    def as_dict(self) -> Dict[str,float]:
        return {
            "legacy_of_precision": self.legacy_of_precision,
            "density_of_exposure": self.density_of_exposure,
            "matrix_of_awareness": self.matrix_of_awareness,
            "ontological_grade": self.ontological_grade,
        }


@dataclass
class VerificationResult:
    matched_count: int
    examined_count: int
    mismatches: List[str] = field(default_factory=list)
    evidence_gaps: List[str] = field(default_factory=list)


def verify_correspondence(map_state: Dict[str, object], reality_state: Dict[str, object]) -> VerificationResult:
    keys=sorted(set(map_state)|set(reality_state)); mismatches=[]; gaps=[]; matched=0
    for key in keys:
        if key not in map_state or key not in reality_state: gaps.append(key); continue
        if map_state[key]==reality_state[key]: matched+=1
        else: mismatches.append(key)
    return VerificationResult(matched,len(keys),mismatches,gaps)
