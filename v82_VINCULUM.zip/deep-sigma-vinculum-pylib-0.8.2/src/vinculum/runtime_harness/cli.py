from __future__ import annotations
import argparse,json,os
from dataclasses import asdict
from .version import PRODUCT,SUBTITLE,VERSION,PRINCIPLE
from .core.context import load_context
from .core.authority import ApproverRoster
from .adapters.lmstudio import LMStudioAdapter
from .runtime import VinculumRuntime
from .deep_sigma.manual_cerpa import ManualCerpaQueue
from .core.ledger import HashLedger
from .bridges.deepsigma_core import probe


def main():
    p=argparse.ArgumentParser(description=f"{PRODUCT} — {SUBTITLE}")
    p.add_argument("--model",default=os.getenv("LM_STUDIO_MODEL")); p.add_argument("--base-url",default=os.getenv("LM_STUDIO_URL","http://localhost:1234/v1"))
    p.add_argument("--prompt"); p.add_argument("--context"); p.add_argument("--list-models",action="store_true"); p.add_argument("--about",action="store_true"); p.add_argument("--probe-core",action="store_true")
    p.add_argument("--ledger",default="vinculum_runtime_ledger.jsonl"); p.add_argument("--manual-queue",default="vinculum_manual_cerpa.jsonl"); p.add_argument("--roster")
    p.add_argument("--list-cases",action="store_true"); p.add_argument("--case"); p.add_argument("--manual-decision",choices=["approve","reject","patch"]); p.add_argument("--actor"); p.add_argument("--authority"); p.add_argument("--note",default=""); p.add_argument("--final-response")
    p.add_argument("--record-applied",action="store_true"); p.add_argument("--post-apply-outcome"); p.add_argument("--expected-state-met",choices=["true","false"]); p.add_argument("--lesson-record-id")
    a=p.parse_args()
    if a.about: print(f"{PRODUCT} v{VERSION}\n{SUBTITLE}\n{PRINCIPLE}"); return
    if a.probe_core: print(json.dumps([asdict(x) for x in probe()],indent=2)); return
    roster=ApproverRoster.from_file(a.roster) if a.roster else None; ledger=HashLedger(a.ledger); q=ManualCerpaQueue(a.manual_queue,roster=roster,ledger=ledger)
    if a.list_cases: print(json.dumps([asdict(x) for x in q.current()],indent=2)); return
    if a.case and a.manual_decision:
        if not a.actor: raise SystemExit("--actor is required")
        print(json.dumps(asdict(q.decide(a.case,a.manual_decision,actor=a.actor,authority=a.authority,note=a.note,final_response=a.final_response)),indent=2)); return
    if a.case and a.record_applied:
        if not a.actor: raise SystemExit("--actor is required")
        print(json.dumps(asdict(q.record_applied(a.case,actor=a.actor,authority=a.authority,final_response=a.final_response)),indent=2)); return
    if a.case and a.post_apply_outcome is not None:
        if not a.actor or a.expected_state_met is None or not a.lesson_record_id: raise SystemExit("--actor, --expected-state-met and --lesson-record-id are required")
        print(json.dumps(asdict(q.close_after_observation(a.case,actor=a.actor,authority=a.authority,observed_outcome=a.post_apply_outcome,expected_state_met=a.expected_state_met=="true",lesson_record_id=a.lesson_record_id)),indent=2)); return
    adapter=LMStudioAdapter(a.model or "__list__",a.base_url)
    if a.list_models: print("\n".join(adapter.list_models())); return
    if not a.model or not a.prompt or not a.context: raise SystemExit("--model, --prompt, and --context are required")
    result=VinculumRuntime(adapter,a.ledger,a.manual_queue,approver_roster=roster).execute(a.prompt,load_context(a.context))
    print(json.dumps(asdict(result),indent=2,ensure_ascii=False))

if __name__=="__main__": main()
