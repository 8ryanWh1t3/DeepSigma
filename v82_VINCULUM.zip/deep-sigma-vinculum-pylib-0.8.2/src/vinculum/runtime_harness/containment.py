"""Host-facing containment contract for model adapters.

This is not an OS sandbox. It defines what the Python harness will accept and makes
external containment (container, VM, OpenShell-like substrate, etc.) easy to enforce.
"""
from __future__ import annotations
from dataclasses import dataclass
import ipaddress
from urllib.parse import urlparse


@dataclass(frozen=True)
class ContainmentPolicy:
    allow_https: bool = True
    allow_loopback_http: bool = True
    max_prompt_chars: int = 250_000
    max_response_chars: int = 250_000


def validate_model_url(base_url: str, policy: ContainmentPolicy = ContainmentPolicy()) -> str:
    parsed = urlparse(base_url)
    if parsed.scheme == "https" and policy.allow_https and parsed.hostname:
        return base_url.rstrip("/")
    if parsed.scheme == "http" and policy.allow_loopback_http and parsed.hostname:
        host = parsed.hostname
        try:
            loopback = ipaddress.ip_address(host).is_loopback
        except ValueError:
            loopback = host.lower() == "localhost"
        if loopback:
            return base_url.rstrip("/")
    raise ValueError("model endpoint must use HTTPS or loopback HTTP; file:// and remote clear-text HTTP are refused")
