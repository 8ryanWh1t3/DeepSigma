"""Canonical Deep Sigma architecture vocabulary and product boundaries.

These declarations describe responsibilities and governance. They do not score truth,
authorize action, or turn inspection output into operational permission.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum

class FoldAspect(str,Enum):
    TIME="time"; WORDS="words"; NUMBERS="numbers"
class JITLens(str,Enum):
    LEGACY_OF_PRECISION="Legacy of Precision"
    DENSITY_OF_EXPOSURE="Density of Exposure"
    MATRIX_OF_AWARENESS="Matrix of Awareness"
    ONTOLOGICAL_GRADE="Ontological Grade"
class TrinityRole(str,Enum):
    PATHFINDER="navigate (interface stub)"
    RESONATOR="examine/test (interface stub)"
    COMPOSER="prepare governed change (interface stub)"
class CerpaStage(str,Enum):
    CLAIM="Claim"; EVENT="Event"; REVIEW="Review"; PATCH="Patch"; APPLY="Apply"; POST_APPLY_CHECK="Post-Apply Check"; LESSON="Lesson"
class MemoryArtifact(str,Enum):
    DLR="Decision Lineage Record"; RS="Reflection Summary"; DS="Drift Signature"; MG="Memory Graph"
@dataclass(frozen=True)
class VinculumSurface:
    name:str; can_author:bool; can_apply:bool; purpose:str
STUDIO=VinculumSurface("VINCULUM Studio",True,False,"draft, explore, assess, construct alternatives, and prepare candidates")
VIEWER=VinculumSurface("VINCULUM",False,False,"read-only inspection, comparison, traversal, and replay")
SEMANTIC_FOLDING_OPERATION=("Distinguish","Arrange","Relate","Continue")
COHERENCE_LOOP=("TRUTH","DECISION","OUTCOME","DRIFT","REFLECTION","PATCH","MEMORY")
MISSION_AUTONOMY_LOOP=("OBSERVE","MODEL","DECIDE","ACT","EFFECT","LEARN","UPDATE")
AUTONOMY_LOOP=MISSION_AUTONOMY_LOOP  # compatibility alias; not the canonical Coherence Ops loop
CANONICAL_MAXIM="Deep Sigma folds reality into navigable meaning without destroying the path back to reality."
AUTHORITY_RULE="Inspection is not authorization. A score is not truth. Only attributable human authority may govern consequential APPLY."
CLOSURE_RULE="APPLY is not closure. Closure requires a post-Apply observation and a lesson/memory record."

def canonical_inventory()->dict[str,tuple[str,...]]:
    return {
        "fold_aspects":tuple(x.value for x in FoldAspect),
        "fold_operation":SEMANTIC_FOLDING_OPERATION,
        "jit_lenses":tuple(x.value for x in JITLens),
        "trinity":tuple(f"{x.name}:{x.value}" for x in TrinityRole),
        "cerpa":tuple(x.value for x in CerpaStage),
        "memory":tuple(f"{x.name}:{x.value}" for x in MemoryArtifact),
        "coherence_loop":COHERENCE_LOOP,
        "mission_autonomy_loop":MISSION_AUTONOMY_LOOP,
    }
